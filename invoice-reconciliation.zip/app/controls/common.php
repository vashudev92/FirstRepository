<?php 
    require_once('config.php');
    $sql_object = new Databases ();
    class common extends Databases{
        function login($email, $pass) 
          {  
            //$pass = md5($pass);  
            $query = "Select * from login where user_name='$email' and password='$pass'"; 
            $check = mysqli_query($this->con, $query); 
            $data = mysqli_fetch_array($check);  
            $result = mysqli_num_rows($check);  
            //echo $data['status']; 
            if ($result == 1) {  
                if($data['status'] == 1){
                    ini_set('session.gc_maxlifetime', 3600);
                    session_start();
                    $_SESSION['login'] = true;  
                    $_SESSION['id'] = $data['sr_no'];  
                    echo '1';
                    exit();
                }
                elseif ($data['status'] == '0') {
                     echo '2'; 
                     exit();
                 } 
            } else {  
                echo "0";  
                exit();
            }  
            mysqli_close($this->con);
         }
         function logout() {  
            //echo("<script>alert('Hello');</script>");
            $_SESSION['login'] = false;  
            session_destroy();  
        } 
        function check_user_type($id)
        {
            $query = "SELECT * FROM  admin_login where sr_no = '$id'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['privlages'];
            return $name;
            mysqli_close($this->con);
        }
        function logged_in_user_id($id)
        {
            $query = "SELECT * FROM  admin_login where sr_no = '$id'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['employee_id'];
            return $name;
            mysqli_close($this->con);
        }
        function get_gap_name($id)
        {
            $query_reason = "SELECT * FROM master_mismatch_reason where sr_no = $id ";
            $row_reason = mysqli_query($this->con, $query_reason);
            $result = mysqli_fetch_assoc($row_reason);
            return $result['reason'];
        }
        function number_record($id,$table)
        {
           $query = "SELECT COUNT(*) FROM ".$table." WHERE upload_id = '$id';";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $total_record = $result['COUNT(*)'];
            return $total_record;
            mysqli_close($this->con);
        }
        function number_record_all($table)
        {
           $query = "SELECT COUNT(*) FROM ".$table;  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $total_record = $result['COUNT(*)'];
            return $total_record;
            mysqli_close($this->con);
        }
		function get_record_detail($id,$column)
        {
            $query = "SELECT * FROM  record_detail where upload_id = '$id'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result[$column];
            return $name;
            mysqli_close($this->con);
        }
        function all_match_record($type)
        {
            if($type == "ALL"){$query = "SELECT COUNT(*) FROM sap_data";
            $query_vendor = "SELECT COUNT(*) FROM vendor_data";}
                else { $query = "SELECT COUNT(*) FROM sap_data where match_type = '$type'";
                if($type == "UM"){$query_vendor = "SELECT COUNT(*) FROM vendor_data where remark_dev = ''";}
                else {$query_vendor = "SELECT COUNT(*) FROM vendor_data where remark_dev = '$type'";}
            }
            $result = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
            $row = mysqli_fetch_assoc($result);
            if (!empty($row)){ $target = $row['COUNT(*)'];} else {$target = "ERROR";}
            //for vendor
            $result_vendor = mysqli_query($this->con, $query_vendor) or die(mysqli_error($this)); 
            $row_result = mysqli_fetch_assoc($result_vendor);
            if (!empty($row_result)){ $target_vendor = $row_result['COUNT(*)'];} else {$target = "ERROR";}
            if($type == "ALL"){return $target + $target_vendor;}
            elseif($type != "MM"){return ($target)*2;}
            elseif($type == "MM"){
                $query = "SELECT COUNT(*) FROM manual_match";
                $result = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
                $row = mysqli_fetch_assoc($result);
                if (!empty($row)){ $target = $row['COUNT(*)'];} else {$target = "ERROR";}
                return $target;}
            mysqli_close($this->con);
        }
        // all records for dashboard
		function match_record($id,$type)
        {
            if($type == "ALL"){$query = "Select
    (select count(*) from sap_data WHERE upload_id = '$id') as welspun,
    (select count(*) from vendor_data WHERE upload_id = '$id') as vendor
    from dual;";
$row = mysqli_query($this->con, $query) or die(mysqli_error($this->con));  
            $result = mysqli_fetch_assoc($row);
            return $record_count = $result['welspun'] + $result['vendor'];
}
        // elseif($type == 'MM'){
        //     $query = "SELECT COUNT(*) FROM manual_match where upload_id = '$id'";
        //     $row = mysqli_query($this->con, $query) or die(mysqli_error($this->con)); 
        //     $result = mysqli_fetch_assoc($row);
        //     return $target = $result['COUNT(*)'];

        // }
                else{ $query = "Select
    (select count(*) from sap_data WHERE upload_id = '$id' AND match_type = '$type') as welspun,
    (select count(*) from vendor_data WHERE upload_id = '$id' AND remark_dev = '$type') as vendor
    from dual;";
$row = mysqli_query($this->con, $query) or die(mysqli_error($this->con));  
            $result = mysqli_fetch_assoc($row);
            return $record_count = $result['welspun'] + $result['vendor'];
}
            
            
			// if($type == "ALL"){$query = "SELECT COUNT(*) FROM sap_data where upload_id = '$id' and comment <> 'AT'";
   //          $query_vendor = "SELECT COUNT(*) FROM vendor_data where upload_id = '$id' and comment <> 'AT'";}
   //          //elseif($type == "FM") { $query = "SELECT COUNT(*) FROM sap_data where upload_id = '$id' and (match_type = '$type' or match_type = 'MM')";}
   //              else { $query = "SELECT COUNT(*) FROM sap_data where upload_id = '$id' and match_type = '$type'";
   //              if($type == "UM"){$query_vendor = "SELECT COUNT(*) FROM vendor_data where upload_id = '$id' and remark_dev = ''";}
   //              else {$query_vendor = "SELECT COUNT(*) FROM vendor_data where upload_id = '$id' and remark_dev = '$type'";}
   //          }
			// $result = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
			// $row = mysqli_fetch_assoc($result);
   //          if (!empty($row)){ $target = $row['COUNT(*)'];} else {$target = "ERROR";}
   //          //for vendor
   //          $result_vendor = mysqli_query($this->con, $query_vendor) or die(mysqli_error($this)); 
   //          $row_result = mysqli_fetch_assoc($result_vendor);
   //          if (!empty($row_result)){ $target_vendor = $row_result['COUNT(*)'];} else {$target = "ERROR";}
   //          if($type == "ALL"){return $target + $target_vendor;}
   //          elseif($type != "MM"){return ($target)*2;}
   //          elseif($type == "MM"){
   //              $query = "SELECT COUNT(*) FROM manual_match where upload_id = '$id'";
   //              $result = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
   //              $row = mysqli_fetch_assoc($result);
   //              if (!empty($row)){ $target = $row['COUNT(*)'];} else {$target = "ERROR";}
   //              return $target;}
            mysqli_close($this->con);
        }
        //count total records for dashboard
        function count_uploaded_sheet()
        {
            $i=0;
            $query = "SELECT COUNT(*) FROM `sap_data` GROUP BY upload_id;";
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
            foreach($row as $result) { $i = $i+1;}
            return $i;
            mysqli_close($this->con);
        }
        //
        function match_record_amount($id,$type)
        {
            $amount = 0;
            $stmt_amt = 0;
            $query = "SELECT * FROM sap_data where upload_id = '$id' and match_type = '$type'";
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
            foreach($row as $result) { $amount = $amount + abs($result['amount']);}
            //vendor
            $query_vendor = "SELECT * FROM vendor_data where upload_id = '$id' and remark_dev = '$type'";
            $row_vendor = mysqli_query($this->con, $query_vendor) or die(mysqli_error($this)); 
            foreach($row_vendor as $result_stmt) {
                        if($result_stmt['debit'] == 0){$stmt_amt = $stmt_amt + abs($result_stmt['credit']);} 
                        else {$stmt_amt = $stmt_amt + abs($result_stmt['debit']);}
                    }
            //total
            return $amount +$stmt_amt;
            mysqli_close($this->con);
        }
        //all records for dashboard
        function all_match_record_amount($type)
        {
            $amount = 0;
            $stmt_amt = 0;
            $query = "SELECT * FROM sap_data where match_type = '$type'";
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
            foreach($row as $result) { $amount = $amount + abs($result['amount']);}
            //vendor
            $query_vendor = "SELECT * FROM vendor_data where remark_dev = '$type'";
            $row_vendor = mysqli_query($this->con, $query_vendor) or die(mysqli_error($this)); 
            foreach($row_vendor as $result_stmt) {
                        if($result_stmt['debit'] == 0){$stmt_amt = $stmt_amt + abs($result_stmt['credit']);} 
                        else {$stmt_amt = $stmt_amt + abs($result_stmt['debit']);}
                    }
            //total
            return $amount +$stmt_amt;
            mysqli_close($this->con);
        }
        function gaps_identified_amount_total($token)
        {
            $query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
            $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this)); 
            $w_amt = 0;
            $v_amt = 0;
            foreach($row_reason as $result_reason) { 
                $w = $this -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']);
                $v = $this -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']);
                $w_amt = (int)$w_amt + (int)$w;
                $v_amt = (int)$v_amt + (int)$v;
            }
            return $v_amt + $w_amt;
        }
        // amount caclulate for seven gaps identified
        function gaps_identified_amount($id,$reason,$applicable_to,$effect)
        {
            $amount = 0;
            $query = "SELECT * FROM reco_summary_amount where upload_id = '$id' and reason = $reason and action_by = $applicable_to";
            //$row = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
            // foreach($row as $result) { 
            //     //if($effect == "+"){ $amount = $amount + abs($result['amount']);}
            //     //elseif($effect == "-"){ $amount = $amount - abs($result['amount']);}
            //     if($applicable_to == 1){
            //         $vendor_amt_check = $this -> common_function("vendor_data","debit",'sr_no',$result['statement_no']);
            //         if($vendor_amt_check == 0){$amount = $amount - $result['amount'];}
            //         else {$amount = $amount + $result['amount'];}
            //     }
                
            //     else {$amount = $amount + $result['amount'];}
                
            // }
            $amount = 0;
            $post = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
            foreach($post as $row) { $sr_no = $row['sr_no'];
            if($row['attached_stmt'] != 0){$stmt_amt = $this -> common_function('sap_data','amount','sr_no',$row['attached_stmt']) . " - ";}
                   if($row['statement_type'] == "sap_data") {
                    $stmt_amt = $this -> common_function($row['statement_type'],'amount','sr_no',$row['statement_no']);
                  }
                  else{
                    $stmt_amt = ($this -> common_function($row['statement_type'],'debit','sr_no',$row['statement_no']) +
                    $this -> common_function($row['statement_type'],'credit','sr_no',$row['statement_no']));
                    $vendor_amt_check = $this -> common_function("vendor_data","debit",'sr_no',$row['statement_no']);
                  } 
                  $difference_amount = $row['amount'];
                  if(ISSET($vendor_amt_check) and $vendor_amt_check == 0){ $difference_amount = -$difference_amount; }
                  
                $amount = $amount + $difference_amount;
            }
            return $amount;
            mysqli_close($this->con);
        }
        function get_record_status($id)
        {
            
            $recon_result = (($this -> common_function("record_detail","company_closing_balance",'upload_id',$id) + $this -> common_function("record_detail","vendor_closing_balance",'upload_id',$id)) - 
            $this -> match_record_amount($id,'UM'));
           // $sql_object -> gaps_identified_amount_total($token));
           if($recon_result == 0){echo '<span class="badge bg-success" style="padding: 12px 6px;font-size: 12px;width: 100px;border-radius: 0px;"><i class="bi bi-check-circle me-1"></i>Rico Matched</span>';}
           else{
            $query_match = "SELECT * FROM  reco_summary_amount where upload_id = '$id'";  
            $row_match = mysqli_query($this->con, $query_match) or die(mysqli_error($this));  
            $result_match = mysqli_fetch_assoc($row_match);    
            if($result_match){
                return '<span class="badge bg-dark" style="padding: 12px;font-size: 12px;width: 100px;border-radius: 0px;"><i class="bi bi-exclamation-triangle me-1"></i> WIP</span>';
            } 
            else {
                return '<span class="badge bg-warning" style="padding: 12px;font-size: 12px;width: 100px;border-radius: 0px;"><i class="bi bi-star me-1"></i> Open</span>';
            }
        }
                //return '<span class="badge bg-success" style="padding: 12px;font-size: 12px;width: 100px;border-radius: 0px;"><i class="bi bi-check-circle me-1"></i> Fully Matched</span>';
            //mysqli_close($this->con);
        }

        //
        function get_record_status_bi($id)
        {
            
            $recon_result = (($this -> common_function("record_detail","company_closing_balance",'upload_id',$id) + $this -> common_function("record_detail","vendor_closing_balance",'upload_id',$id)) - 
            $this -> match_record_amount($id,'UM'));
           // $sql_object -> gaps_identified_amount_total($token));
           if($recon_result == 0){return 'RECO MATCHED';}
           else{
            $query_match = "SELECT * FROM  reco_summary_amount where upload_id = '$id'";  
            $row_match = mysqli_query($this->con, $query_match) or die(mysqli_error($this));  
            $result_match = mysqli_fetch_assoc($row_match);    
            if($result_match){
                return 'WIP';
            } 
            else {
                return 'OPEN';
            }
        }
                //return '<span class="badge bg-success" style="padding: 12px;font-size: 12px;width: 100px;border-radius: 0px;"><i class="bi bi-check-circle me-1"></i> Fully Matched</span>';
            //mysqli_close($this->con);
        }

        //
        function get_vendor_category($code)
        {
            $query = "SELECT * FROM  master_vendor_cateory where vendor_code = '$code'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['category'];
            return $name;
            mysqli_close($this->con);
        }
        function get_vendor_name($code)
        {
            $query = "SELECT * FROM  master_vendor_cateory where vendor_code = '$code'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['vendor_name'];
            return $name;
            mysqli_close($this->con);
        }
        function get_company_name($code)
        {
            $query = "SELECT * FROM  master_vendor_cateory where company_code = '$code'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['company_name'];
            return $name;
            mysqli_close($this->con);
        }
        function get_vendor_code($code)
        {
            $query = "SELECT * FROM  master_vendor_cateory where vendor_code = '$code'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
            $result = mysqli_fetch_assoc($row);
            $name = $result['vendor_code'];
            return $name;
            mysqli_close($this->con);
        }
        //common function
        function common_function($table,$field,$condition,$id)
        {

            $query = "SELECT $field FROM  $table where $condition = '$id'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
            if (mysqli_num_rows($row)) {
            $result = mysqli_fetch_assoc($row);
            $name = $result[$field];
            return $name; }
            else {return 0;}
            mysqli_close($this->con);
        }

        //master dashboard functions begins here
        function vendor_count($compoany_name,$vendor_category,$finincial_year){
               $whereClauses=array();
               if($compoany_name != 0 ){ $whereClauses[] ="company_code = '$compoany_name'";}
               if($vendor_category != 0 ){ $whereClauses[] ="category = '$vendor_category'";}
               $where='';
               if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
               $query = "SELECT COUNT(*) FROM master_vendor_cateory $where";  
                $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
                $result = mysqli_fetch_assoc($row);
                $total_record = $result['COUNT(*)'];
                return $total_record;
                mysqli_close($this->con);
        }
        function uploaded_vendor_count($company_code,$vendor_category,$finincial_year){
               $whereClauses=array();
               if($company_code != 0 ){ $whereClauses[] ="company_code = '$company_code'";}
               if($vendor_category != 0 ){ $whereClauses[] ="category = '$vendor_category'";}
               $where='';
               if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
               $query = "SELECT COUNT(*) FROM record_detail $where";  
                $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
                $result = mysqli_fetch_assoc($row);
                $total_record = $result['COUNT(*)'];
                return $total_record;
                mysqli_close($this->con);
        }
        function fully_completed_statment($company_code,$vendor_category,$finincial_year){
               $whereClauses=array();
               if($company_code != 0 ){ $whereClauses[] ="company_code = '$company_code'";}
               if($vendor_category != 0 ){ $whereClauses[] ="category = '$vendor_category'";}
               $query = "SELECT COUNT(*) FROM `record_detail` where category = '$vendor_category'";
                $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
                foreach($row as $result) { $i = $i+1;}
            //
               $where='';
               if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
               $query = "SELECT COUNT(*) FROM record_detail $where";  
                $row = mysqli_query($this->con, $query) or die(mysqli_error($this));  
                $result = mysqli_fetch_assoc($row);
                $total_record = $result['COUNT(*)'];
                return $total_record;
                mysqli_close($this->con);
        }
        // Update withholding Tax summary while uploading statement function in index.php
        function auto_with_holding_tax(){
            $current_date_time=date('Y-m-d H:i:s');
            $query = "SELECT * FROM  record_detail where remark_dev != 'WHTD'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
            if (mysqli_num_rows($row)) {  
            $result = mysqli_fetch_assoc($row);
            $upload_id = $result['upload_id'];
            $query = "SELECT * FROM  vendor_data where upload_id = '$upload_id' and remark_dev = 'PM'";
            $result = mysqli_query($this->con, $query) or die(mysqli_error($this)); 
            foreach($result as $row) {
                $match_id = $row['sr_no'];
                $query_sap = "SELECT * FROM  sap_data where match_id = '$match_id'";
                $row_sap = mysqli_query($this->con, $query_sap) or die(mysqli_error($this));  
                $post_post = mysqli_fetch_assoc($row_sap);
                $w_amount = $post_post['amount'];
                $attached_stmt = $post_post['sr_no'];
                $tds = abs($post_post['tds']);
                if($row['debit'] != 0){ $temp_diff = $row['debit'] + $w_amount;} 
                else { $temp_diff = $row['credit'] - $w_amount; }
                $vendor_amount = $temp_diff + $w_amount;
                if($tds == $temp_diff){
                    $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`, `statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`,`attached_stmt`, `date_time`) VALUES ('$match_id','$upload_id','vendor_data','$tds','Auto Check TDS','1','10','PM','$attached_stmt','$current_date_time')";
                    mysqli_query($this->con, $query_insert) or die(mysqli_error($this->con));
                    //update vendor data
                      $query = "UPDATE `vendor_data` SET comment = 'AT',remark_dev = 'MM' where sr_no = $match_id";  
                      mysqli_query($this->con, $query) or die(mysqli_error($this->con));
                      //update vendor data
                      $query = "UPDATE `sap_data` SET comment = 'AT',match_type = 'MM' where match_id = $match_id";  
                      mysqli_query($this->con, $query) or die(mysqli_error($this->con));

                }
            }
            $query = "update `record_detail` set remark_dev = 'WHTD' where upload_id = '$upload_id'";  
            $row = mysqli_query($this->con, $query) or die(mysqli_error($this));
        }
    }
    //BI Dashboard Update function
    function update_bi_table()
    {
        $query_reason = "SELECT * FROM reco_datatable_bi where status = 0";
        $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this)); 
        foreach($row_reason as $result_reason) { 
            $upload_id = $result_reason['upload_id'];
            //$closing_balance_difference = $result_reason['closing_balance_difference'];
            
            $closing_balance_difference = $result_reason['company_closing_balance'] + $result_reason['vendor_closing_balance'];
            $closing_balance_difference = $closing_balance_difference;
            $rico_amount = $this -> gaps_identified_amount_total($upload_id);
            //$rico_amount = abs($rico_amount);
            $pending_amount = $closing_balance_difference - $rico_amount;
            $pending_amount = abs($pending_amount);
            $reco_status = $this -> get_record_status_bi($upload_id);
            
            $query_reason = "UPDATE `reco_datatable_bi` SET  `closing_balance_difference` = $closing_balance_difference,
            `rico_amount` = $rico_amount, `pending_amount` = $pending_amount,`rico_status`='$reco_status' 
            where upload_id = '$upload_id'";
            $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this)); 
        }
    } 
    // Insert IN BI Record Table
    function Insert_bi_table()
    {
        $query_reason = "SELECT * FROM record_detail";
        $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this->con)); 
        foreach($row_reason as $result_reason) { 
            $upload_id = $result_reason['upload_id'];
            $vendor_name = $result_reason['vendor_name'];
            $vendor_code = $result_reason['vendor_code'];
            $company_code = $result_reason['company_code'];
            $company_name = $result_reason['company_name'];
            $vendor_closing_balance = $result_reason['vendor_closing_balance'];
            $company_closing_balance = $result_reason['company_closing_balance'];
            $category = $result_reason['category'];
            $stmt_start_date = $result_reason['stmt_start_date'];
            $stmt_end_date = $result_reason['stmt_end_date'];
            $query_reason = "INSERT INTO `reco_datatable_bi`(`upload_id`, `company_name`, `company_code`, `company_closing_balance`, `vendor_name`, `vendor_code`, `vendor_closing_balance`) VALUES ('$upload_id','$company_name','$company_code','$company_closing_balance','$vendor_name','$vendor_code','$vendor_closing_balance')";
            $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this));
        }
    }
    //BI Reason Data
    //BI Dashboard Update function
    function reason_bi_table()
    { 
        $query_reason = "SELECT * FROM reco_datatable_bi where status = 0";
        $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this->con)); 
        foreach($row_reason as $result_reason) { 
            $upload_id = $result_reason['upload_id'];
            $vendor_name = $result_reason['vendor_name'];
            $vendor_code = $result_reason['vendor_code'];
            $company_code = $result_reason['company_code'];
            $company_name = $this -> common_function('master_vendor_cateory','company_name','company_code',$company_code);
            $category = $result_reason['category'];
            $stmt_start_date = $result_reason['stmt_start_date'];
            $stmt_end_date = $result_reason['stmt_end_date'];
            $query_reason = "UPDATE `reco_summary_amount_bi` SET 
            `vendor_name`='$vendor_name',`vendor_code`='$vendor_code',`company_name`='$company_name',`company_code`='$company_code',`category`='$category',`stmt_start_date`='$stmt_start_date',`stmt_end_date`='$stmt_end_date'
            where upload_id = '$upload_id'";
            $row_reason = mysqli_query($this->con, $query_reason) or die(mysqli_error($this)); 

        }
    }
  
} ?>
