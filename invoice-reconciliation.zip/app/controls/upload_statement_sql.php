<?php 
ini_set('max_execution_time', '3000'); //300 seconds = 5 minutes
//ini_set('max_execution_time', '0'); // for infinite time of execution 
require_once '../../spreadsheet/vendor/autoload.php';
 
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
require_once('common.php');
   $sql_object = new common ();
   $action = $_POST["action"];
    //if($action == "INSERT"){}
   $upload_id=uniqid();
   $str = $_POST["select_vendor"];
   $headers = explode('[', $str);
    $vendor_code = substr($headers[1], 0, -1);
    $vendor_name = $sql_object->get_vendor_name($vendor_code);
    //$vendor_code = $sql_object->get_vendor_code($company_code);
    $company_code = $_POST["select_company"];
    $company_name = $sql_object->get_company_name($company_code);
    
    // $vendor_name = $_POST["vendor_name"];
    // $vendor_code = $_POST["vendor_code"];
    // $company_name = $_POST["company_name"];
    // $company_code = $_POST["company_code"];
    $company_opening_balance = $_POST["company_opening_balance"];
    $company_closing_balance = $_POST["company_closing_balance"];
    $vendor_opening_balance = $_POST["vendor_opening_balance"];
    $vendor_closing_balance = $_POST["vendor_closing_balance"];
    $category = $sql_object->get_vendor_category($vendor_code);
    $start_period = date("Y-m-d", strtotime($_POST["start_period"]));
    $end_period = date("Y-m-d", strtotime($_POST["end_period"]));
    $status = 0;
    $time_stamp = date('Y-m-d H:i:s');
    //Vendor CSV Upload
    $fileName = $_FILES["vendor_file"]["tmp_name"];
    $status=0;
    $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    if (isset($_FILES['vendor_file']['name']) && in_array($_FILES['vendor_file']['type'], $file_mimes)) {
        $vendor_file = fopen($fileName, "r");
        $flag = true;
        $k=1;
        $arr_file = explode('.', $_FILES['vendor_file']['name']);
        $extension = end($arr_file);
     
        if('csv' == $extension) {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
 
        $spreadsheet = $reader->load($_FILES['vendor_file']['tmp_name']);
 
        $sheetData = $spreadsheet->getActiveSheet()->toArray();
        if (!empty($sheetData)) {
            for ($i=1; $i<count($sheetData); $i++) {
            $date = "";
            if (isset($sheetData[$i][0])) {
                $sheet_date = mysqli_real_escape_string($sql_object->con, $sheetData[$i][0]);
                if (strpos($sheet_date, '/') != false) {$old_date = explode('/', $sheet_date); }
                else if (strpos($sheet_date, '-') != false) {$old_date = explode('-', $sheet_date); }
                else if (strpos($sheet_date, '.') != false) {$old_date = explode('.', $sheet_date); }
                $date = $old_date[2].'-'.$old_date[1].'-'.$old_date[0];
            }
            $particular = "";
            if (isset($sheetData[$i][1])) {
                $particular = mysqli_real_escape_string($sql_object->con, $sheetData[$i][1]);
            }
            $document_type = "";
            if (isset($sheetData[$i][2])) {
                $document_type = mysqli_real_escape_string($sql_object->con, $sheetData[$i][2]);
            }
            $invoice_no = "";
            if (isset($sheetData[$i][3])) {
                $invoice_no = trim(mysqli_real_escape_string($sql_object->con, $sheetData[$i][3]));
            }
            $debit = "";
            if (isset($sheetData[$i][4])) {
                $debit = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][4]);
            }
            $credit = "";
            if (isset($sheetData[$i][5])) {
                $credit = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][5]);
            }
            $token_id=$k;
            $sqlInsert = array('date'=>$date,'particular'=>$particular, 'document_type'=>$document_type, 
            'invoice_no'=>$invoice_no, 'debit'=>$debit, 'credit'=>$credit, 'upload_id'=>$upload_id, 'token_id'=>$token_id,'status'=>$status, 'time_stamp'=>$time_stamp,'company_name'=>$company_name, 'company_code'=>$company_code,'vendor_name'=>$vendor_name , 'vendor_code'=>$vendor_code ,'category'=>$category);
            if($sql_object->insert('vendor_data', $sqlInsert)){ //echo "1";
             } 
            $k++;
        }
    }
}
    fclose($vendor_file);
    // SAP File Upload
    $j=1;
    $fileName_csv = $_FILES["csv_file"]["tmp_name"];
    $arr_file = explode('.', $_FILES['csv_file']['name']);
        $extension = end($arr_file);
     $csv_file = fopen($fileName_csv, "r");
        if('csv' == $extension) {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
 
        $spreadsheet = $reader->load($_FILES['csv_file']['tmp_name']);
 
        $sheetData = $spreadsheet->getActiveSheet()->toArray();
        if (!empty($sheetData)) {
            for ($i=1; $i<count($sheetData); $i++) {
            $document_date = "";
            if (isset($sheetData[$i][0])) {
                $sheet_date = mysqli_real_escape_string($sql_object->con, $sheetData[$i][0]);
                if (strpos($sheet_date, '/') != false) {$old_date = explode('/', $sheet_date); }
                elseif (strpos($sheet_date, '-') != false) {$old_date = explode('-', $sheet_date); }
                elseif (strpos($sheet_date, '.') != false) {$old_date = explode('.', $sheet_date); }
                $document_date = $old_date[2].'-'.$old_date[1].'-'.$old_date[0];
            }
            $document_type = "";
            if (isset($sheetData[$i][1])) {
                $document_type = mysqli_real_escape_string($sql_object->con, $sheetData[$i][1]);
            }
            $document_number = "";
            if (isset($sheetData[$i][2])) {
                $document_number = mysqli_real_escape_string($sql_object->con, $sheetData[$i][2]);
            }
            $reference_no = "";
            if (isset($sheetData[$i][3])) {
                $reference_no = trim(mysqli_real_escape_string($sql_object->con, $sheetData[$i][3]));
            }
            $posting_date = "";
            if (isset($sheetData[$i][4])) {
                $sheet_date = mysqli_real_escape_string($sql_object->con, $sheetData[$i][0]);
                if (strpos($sheet_date, '/') !== false) {$old_date = explode('/', $sheet_date); }
                elseif (strpos($sheet_date, '-') !== false) {$old_date = explode('-', $sheet_date); }
                elseif (strpos($sheet_date, '.') !== false) {$old_date = explode('.', $sheet_date); }
                $posting_date = $old_date[2].'-'.$old_date[1].'-'.$old_date[0];
            }
            $amount = "";
            if (isset($sheetData[$i][5])) {
                $amount = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][5]);
            }
            $tds = "";
            if (isset($sheetData[$i][6])) {
                $tds = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][6]);
            }
            //check matching criteria
            if($amount < 0){$am = 'debit';} else {$am = 'credit';}
            $query_match = "SELECT * FROM vendor_data where invoice_no = '$reference_no' and date = '$document_date' and $am = '".abs($amount)."' and upload_id = '$upload_id'";  
            $row_match = mysqli_query($sql_object->con, $query_match) or die(mysqli_error($sql_object->con));  
            $result_match = mysqli_fetch_assoc($row_match);
            if (!empty($result_match)){
                $match_id = $result_match['sr_no'];
                $match_type='FM';
                $status=1;
            }
            else{
            $query_match = "SELECT * FROM vendor_data where invoice_no = '$reference_no' and date = '$document_date' and upload_id = '$upload_id'";  
            $row_match = mysqli_query($sql_object->con, $query_match) or die(mysqli_error($sql_object->con));  
            $result_match = mysqli_fetch_assoc($row_match);
            if (!empty($result_match)){
                $match_id = $result_match['sr_no'];
                $match_type='PM';
                $status=2;
                }
                else{
                    $match_id = 0;
                    $match_type='UM';
                    $status=3;
                }
            }

            //insert data in sap table
            $sqlInsert = array('document_date'=>$document_date,'document_type'=>$document_type,
                'document_number'=>$document_number, 'reference_no'=>$reference_no,'posting_date'=>$posting_date,
            'amount'=>$amount,'tds'=>$tds, 'upload_id'=>$upload_id ,'token_id'=>$j,'status'=> $status,'time_stamp'=>$time_stamp,'match_id'=> $match_id, 'match_type'=>$match_type,'company_name'=>$company_name, 'company_code'=>$company_code,'vendor_name'=>$vendor_name , 'vendor_code'=>$vendor_code,'category'=>$category);
                    if($sql_object->insert('sap_data', $sqlInsert)){ } 
            //Update Vendor Table Status
            $query = "UPDATE `vendor_data` SET `status` = $status, `remark_dev` = '$match_type'  where `sr_no` = $match_id ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));        
            $j++;
        }
    }
    fclose($csv_file);
     //insert data in record_details table
    $sqlInsert = array('upload_id'=>$upload_id , 'company_name'=>$company_name, 'company_code'=>$company_code,
        'company_opening_balance'=> $company_opening_balance ,'company_closing_balance'=> $company_closing_balance, 
        'vendor_name'=>$vendor_name , 'vendor_code'=>$vendor_code , 'vendor_opening_balance'=> $vendor_opening_balance ,
        'vendor_closing_balance'=> $vendor_closing_balance , 'stmt_start_date'=> $start_period, 'stmt_end_date'=>
        $end_period ,'flag'=> 0, 'remark_dev'=> '', 'datetime' => $time_stamp,'category' => $category);
    $sql_object->insert('record_detail', $sqlInsert);

    // Power BI Query Insert
   // $sqlInsert = array('upload_id'=>$upload_id , 'company_name'=>$company_name, 'company_code'=>$company_code,
   //      'company_closing_balance'=> $company_closing_balance, 
   //      'vendor_name'=>$vendor_name , 'vendor_code'=>$vendor_code ,
   //      'vendor_closing_balance'=> $vendor_closing_balance ,`closing_balance_difference` => ($company_closing_balance + $vendor_closing_balance), 'stmt_start_date'=> $start_period, 'stmt_end_date'=>
   //      $end_period ,'flag'=> 0, 'remark_dev'=> '', 'datetime' => $time_stamp,'category' => $category);
   //  $sql_object->insert('reco_datatable_bi', $sqlInsert);


    // for Updating records
    if ($action == "UPDATE") {
        $old_upload_id=$_POST["upload_id"];
        $query = "DELETE from `vendor_data` WHERE `upload_id` = '$old_upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `sap_data` WHERE `upload_id` = '$old_upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `record_detail` WHERE `upload_id` = '$old_upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `manual_match` WHERE `upload_id` = '$old_upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `reco_summary_amount` WHERE `upload_id` = '$old_upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
    }

?>
<div class="card">
            <div class="card-body">
              <h5 class="card-title">Uploaded Statement Details</h5>
              <!-- Table with stripped rows -->
              <table class="table rec-table">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#.</th>
                    <th scope="col">Company Name.</th>
                    <th scope="col">Company Code.</th>
                    <th scope="col">Vendor Name.</th>
                    <th scope="col">Vendor Code.</th>
                    <th scope="col">Vendor Record</th>
                    <th scope="col">Company Record</th>
                    <th scope="col">Exact Match</th>
                    <th scope="col">Partial Match</th>
                    <th scope="col">Current Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="text-center" >
                    <td>1<?php $sql_object->auto_with_holding_tax(); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($upload_id ,'company_name'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($upload_id ,'company_code'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($upload_id ,'vendor_name'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($upload_id ,'vendor_code'); ?></td>
                    <td><?php  echo $sql_object -> number_record($upload_id,'vendor_data'); ?></td>
                    <td><?php  echo $sql_object -> number_record($upload_id,'sap_data'); ?></td>
                    <td><?php  echo $sql_object -> match_record($upload_id,'FM'); ?></td>
                    <td><?php  echo $sql_object -> match_record($upload_id,'PM'); ?></td>
                    <td>status</td>
                    <td><button type="button" class="btn btn-primary btn-sm" onclick="window.location.href='invoice-reconciliation.php?token=<?php echo $upload_id; ?>'">View</button></td>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>