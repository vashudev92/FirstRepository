<?php  
   require_once('common.php');
   $sql_object = new common ();
   $action = mysqli_real_escape_string($sql_object->con, $_POST['action']); 
   if($action == 'SAP'){
      $save_statement_action = mysqli_real_escape_string($sql_object->con, $_POST['save_statement_action']);
      if($save_statement_action == 'UM'){
         $matching_id = uniqid();
         $matching_amount_check = mysqli_real_escape_string($sql_object->con, $_POST['matching_amount_check']);
         $upload_id = mysqli_real_escape_string($sql_object->con, $_POST['upload_id']);
         if(isset($_POST['sap_check'])){
            $sr_no = $_POST['sap_check']; 
            $reason = $_POST['sap_reason']; 
            $user_action = $_POST['sap_action']; 
            $comment = $_POST['sap_comment']; 
            $sap_amount = $_POST['sap_amount']; 
            $len = sizeof($sr_no);
            for ($i=0; $i < $len; $i++) { 
               $sap_reason_count = $_POST['sap_reason_count'][$i]; 
               if($matching_amount_check == 0){
                  $query = "UPDATE `sap_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]',match_type = 'MM',status = 1 where sr_no = $sr_no[$i] ";  
                  mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
                  //insert Mismatch
                  $insert_sap = array('statement_no' => $sr_no[$i], 'statement_type' => 'sap_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
                 $sql_object->insert('manual_match', $insert_sap);
               } else {
                  $query = "UPDATE `sap_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]' where sr_no = $sr_no[$i] ";  
                  mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
               }
               // for seperate reasons
                for ($j=0; $j <= $sap_reason_count; $j++) { 
               $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`, `statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`, `date_time`) VALUES ('$sr_no[$i]','$upload_id','sap_data','$sap_amount[$j]','$comment[$j]','$user_action[$j]','$reason[$j]','','$current_date_time')";  
               mysqli_query($sql_object->con, $query_insert) or die(mysqli_error($sql_object->con));
               }
            }
         }
         // vendor record update for partial mismatch
         if(isset($_POST['vendor_check'])){
            $sr_no = $_POST['vendor_check']; 
            $reason = $_POST['vendor_reason']; 
            $user_action = $_POST['vendor_action']; 
            $comment = $_POST['vendor_comment']; 
             $vendor_amount = $_POST['vendor_amount']; 
            $len = sizeof($sr_no);
            for ($i=0; $i < $len; $i++) { 
               $vendor_reason_count = $_POST['vendor_reason_count'][$i]; 
               if($matching_amount_check == 0){
                     $query = "UPDATE `vendor_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]',remark_dev = 'MM',status = 1 where sr_no = $sr_no[$i] ";  
                     mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

                      // Insert mismatch 
                     $insert_vendor = array('statement_no' => $sr_no[$i], 'statement_type' => 'vendor_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
                    $sql_object->insert('manual_match', $insert_vendor);
               } else {
                  $query = "UPDATE `vendor_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]' where sr_no = $sr_no[$i] ";  
                     mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
               }
                  for ($j=0; $j <= $vendor_reason_count; $j++) { 
               $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`,`statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`, `date_time`) VALUES ('$sr_no[$i]','$upload_id','vendor_data','$vendor_amount[$j]','$comment[$j]','$user_action[$j]','$reason[$j]','','$current_date_time')";  
               mysqli_query($sql_object->con, $query_insert) or die(mysqli_error($sql_object->con));
               }
            }
         }
         echo '1';
      }
      elseif($save_statement_action == 'PM'){
         $sr_no = $_POST['vendor_check']; 
         $reason = $_POST['vendor_reason']; 
         $user_action = $_POST['vendor_action']; 
         $comment = $_POST['vendor_comment']; 
         $vendor_amount = $_POST['vendor_amount']; 
         $vendor_reason_count = $_POST['vendor_reason_count'][$i]; 
         $len = sizeof($sr_no);
         for ($i=0; $i < $len; $i++) { 
            $query = "UPDATE `vendor_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]' where sr_no = $sr_no[$i]";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
            for ($j=0; $j <= $vendor_reason_count; $j++) { 
               $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`, `statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`, `date_type`) VALUES ('$sr_no[$i]','$upload_id','vendor_data','$vendor_amount[$j]','$comment[$j]','$user_action[$j]','$reason[$j]','','$current_date_time')";  
               mysqli_query($sql_object->con, $query_insert) or die(mysqli_error($sql_object->con));
            }

            //upadte sap table reason
            $query_sap = "UPDATE `sap_data` SET reason = $reason[$i] , action = $user_action[$i], comment = '$comment[$i]' where match_id = $sr_no[$i] ";  
            mysqli_query($sql_object->con, $query_sap) or die(mysqli_error($sql_object->con));

            echo '2'; }
      }
   }
   
?>