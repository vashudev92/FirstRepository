<?php  
   require_once('common.php');
   $sql_object = new common ();
   $action = mysqli_real_escape_string($sql_object->con, $_POST['action']);
   if($action == 'INSERT'){
   		$logic_name = mysqli_real_escape_string($sql_object->con, $_POST['logic_name']);
        $logic_nature = mysqli_real_escape_string($sql_object->con, $_POST['logic_nature']); 
   		$query = "INSERT INTO `master_mismatch_reason`(`reason`, `effect`, `status`, `remark`,`date_time`) VALUES ('$logic_name','$logic_nature',1,'NEW','$current_date_time')";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
        if($result){echo "1";} else {echo $result;}
   }
   if($action == 'UPDATE'){
   	    $logic_name = mysqli_real_escape_string($sql_object->con, $_POST['logic_name']);
        $logic_nature = mysqli_real_escape_string($sql_object->con, $_POST['logic_nature']); 
   	    $sr_no = mysqli_real_escape_string($sql_object->con, $_POST['sr_no']);
   		$query = "UPDATE `master_mismatch_reason` SET `reason`='$logic_name',`effect`='$logic_nature',`status`=1,`remark`='UPDATED',`date_time`='$current_date_time' WHERE `sr_no` = $sr_no";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
        if($result){echo "2";} else {echo $result;}
   }
   if($action == 'DELETE'){
   	    $sr_no = mysqli_real_escape_string($sql_object->con, $_POST['sr_no']);
   		$query = "DELETE from `master_mismatch_reason` WHERE `sr_no` = $sr_no";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
        if($result){echo "3";} else {echo $result;}
   }
   if($action == 'DELETE_STATEMENTS'){
   	    $upload_id = mysqli_real_escape_string($sql_object->con, $_POST['sr_no']);
   	   $query = "DELETE from `vendor_data` WHERE `upload_id` = '$upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `sap_data` WHERE `upload_id` = '$upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `record_detail` WHERE `upload_id` = '$upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `manual_match` WHERE `upload_id` = '$upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        $query = "DELETE from `reco_summary_amount` WHERE `upload_id` = '$upload_id'";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
        if($result){echo "4";} else {echo $result;}
   }
   if($action == 'DELETE_RECORD'){
         $sr_no = mysqli_real_escape_string($sql_object->con, $_POST['sr_no']);
         $type = $sql_object -> common_function('reco_summary_amount','statement_type','sr_no',$sr_no);
         $statement_no = $sql_object -> common_function('reco_summary_amount','statement_no','sr_no',$sr_no);
         $remark = $sql_object -> common_function('reco_summary_amount','remark','sr_no',$sr_no);

         if($type == 'sap_data'){ $table_field = 'match_type';} else {$table_field = 'remark_dev';}

          if($remark == "PM"){
          $query = "UPDATE `sap_data` set comment = '', match_type = 'PM' WHERE `match_id` = $statement_no";  
          $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
          //
          $query = "UPDATE `vendor_data` set comment = '', remark_dev = 'PM' WHERE `sr_no` = $statement_no";  
          $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
         }
         
         $query = "UPDATE `$type` set comment = '', $table_field = 'UM' WHERE `sr_no` = $statement_no";  
         $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

         $query = "DELETE from `reco_summary_amount` WHERE `sr_no` = $sr_no";  
        $result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));

        if($result){echo "5";} else {echo $result;}
   }
