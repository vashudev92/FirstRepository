<?php 
ini_set('max_execution_time', '3000'); //300 seconds = 5 minutes
//ini_set('max_execution_time', '0'); // for infinite time of execution 
require_once('common.php');
$sql_object = new common ();
$query = "SELECT * FROM sap_data "; 
$row = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));  
foreach($row as $result) {
   $sap_invoice_no = $result['reference_no']; 
   $sap_invoice_date = $result['document_date'];
   $sap_sr_no = $result['sr_no'];
}

?>