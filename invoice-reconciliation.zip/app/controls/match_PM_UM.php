<?php 
require_once('common.php');
    $sql_object = new common ();
	$welspun_record = mysqli_real_escape_string($sql_object->con, $_POST['welspun_record']);
	$vendor_record = mysqli_real_escape_string($sql_object->con, $_POST['vendor_record']);
  $upload_id = mysqli_real_escape_string($sql_object->con, $_POST['upload_id']);
?>
 <form id="pm_um_mm">
  
<div class="modal fade show" id="disablebackdrop" tabindex="-1" data-bs-backdrop="true" aria-modal="true" role="dialog" style="display: block; padding-left: 0px;">
  <input type="hidden" name="save_statement_action_text" value="UM">
  <input type="hidden" name="matching_amount_check" value="0">
  <input type="hidden" name="action" value="0">
  <input type="hidden" name="upload_id" value="<?php echo $upload_id; ?>">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Selected Statements</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <table class="table rec-table">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#</th>
                    <th scope="col">Invoice Details</th>
                    <th scope="col">Invoice Amount Details</th>
                    <th scope="col">Statement of </th>
                  </tr>
                </thead>
                <tbody>
        <?php 
        $tags = explode(',',$welspun_record);
        $tag_length = sizeof($tags) - 1;
        $welspun_amount = 0;
        $j=1;
        for ($i=0; $i < $tag_length; $i++) { 
        	$welspun_amount = $welspun_amount + $sql_object -> common_function('sap_data','amount','sr_no',$tags[$i])
         	?>
                  <tr class="text-center">
                    <td>
                      <input class="form-check-input w_check_1" name="sap_check[]" type="checkbox" value="<?php echo $tags[$i];?>" checked onclick="return false"/> <?php echo $j; ?>
                    </td>
                    <td>
                    	<?php  echo $sql_object -> common_function('sap_data','reference_no','sr_no',$tags[$i]) ?></br>
                    	<?php  echo date("d/m/Y", strtotime($sql_object -> common_function('sap_data','document_date','sr_no',$tags[$i]))) ?>	
                    </td>
                    <td>
   						<?php  echo "₹ ".($sql_object -> common_function('sap_data','amount','sr_no',$tags[$i]) + $sql_object -> common_function('sap_data','tds','sr_no',$tags[$i])) ?></br>
   						<span style="font-size: 9px;">[<?php  echo "₹ ".$sql_object -> common_function('sap_data','amount','sr_no',$tags[$i]). " + ". $sql_object -> common_function('sap_data','tds','sr_no',$tags[$i]) ?> (TDS)] </span>
                    </td>
                    <td>Welspun</td>
                  </tr>
      <?php $j++;}  ?>

      <?php 
        $tags = explode(',',$vendor_record);
        $tag_length = sizeof($tags) - 1;
        $vendor_amount_c = 0;
        $vendor_amount_d = 0;
        for ($i=0; $i < $tag_length; $i++) { 
        	$vendor_amount_d = $vendor_amount_d + $sql_object -> common_function('vendor_data','debit','sr_no',$tags[$i]);
        	 $vendor_amount_c = $vendor_amount_c + $sql_object -> common_function('vendor_data','credit','sr_no',$tags[$i]);
         	?>
                  <tr class="text-center">
                    <td>
                      <input class="form-check-input w_check_1" name="vendor_check[]" type="checkbox" value="<?php echo $tags[$i];?>" checked onclick="return false"/> <?php echo $j; ?>
                    </td>
                    <td>
                    	<?php  echo $sql_object -> common_function('vendor_data','invoice_no','sr_no',$tags[$i]) ?></br>
                    	<?php  echo date("d/m/Y", strtotime($sql_object -> common_function('vendor_data','date','sr_no',$tags[$i]))) ?>	
                    </td>
                    <td>
   						<?php  echo "₹ ".($sql_object -> common_function('vendor_data','debit','sr_no',$tags[$i]) + $sql_object -> common_function('vendor_data','credit','sr_no',$tags[$i])) ?></br>
                    </td>
                    <td>Vendor</td>
                  </tr>
      <?php $j++; }  ?>
      <thead>
                  <tr  class="text-center">
                    <th scope="col">#</th>
                    <th scope="col">Difference:</th>
                    <th scope="col"><?php 
                    $vendor_amount = abs($vendor_amount_d - $vendor_amount_c);
                    echo $welspun_amount - $vendor_amount ?></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                </tbody>
              </table>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary" <?php if(($welspun_amount + $vendor_amount) != 0){echo "disabled";}?>>Save</button>
                    </div>
                  </div>
                </div>
              </div>
              </form>
<script type="text/javascript">
  $("#pm_um_mm").on('submit',(function(e) {
  if(e.isDefaultPrevented())
  { 
  }
    else
    {
      $(".loader-layout").toggle();
e.preventDefault();
$.ajax({
url: "app/controls/reco_action_sql.php",
type: "POST",            
data: new FormData(this), 
contentType: false,       
cache:false,            
processData:false,       
success: function(data)  
{
  //alert(data);
  $(".loader-layout").toggle();
  $("#disablebackdrop").modal('hide');
  if(data == 'UM'){$("#btn_unmatch").click();}
  else if(data == 'PM'){$("#btn_partialmatch").click();}
  else{ alert(data);}

}
});
    }
}));

</script>