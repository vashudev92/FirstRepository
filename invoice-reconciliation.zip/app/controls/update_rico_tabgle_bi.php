<<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
    <form action="">
        <input type="file" name="excel_file">
    </form>
</body>
</html>
<?php 
ini_set('max_execution_time', '3000'); //300 seconds = 5 minutes
//ini_set('max_execution_time', '0'); // for infinite time of execution 
require_once '../../spreadsheet/vendor/autoload.php';
 
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
require_once('common.php');
   $sql_object = new common ();
   $action = $_POST["action"];
    //if($action == "INSERT"){}
   $upload_id=uniqid();
   $str = $_POST["select_vendor"];
   $headers = explode('[', $str);
    $vendor_code = substr($headers[1], 0, -1);
    $vendor_name = $sql_object->get_vendor_name($vendor_code);
    //$vendor_code = $sql_object->get_vendor_code($company_code);
    $company_code = $_POST["select_company"];
    $company_name = $sql_object->get_company_name($company_code);
    
    // $vendor_name = $_POST["vendor_name"];
    // $vendor_code = $_POST["vendor_code"];
    // $company_name = $_POST["company_name"];
    // $company_code = $_POST["company_code"];
    $company_opening_balance = $_POST["company_opening_balance"];
    $company_closing_balance = $_POST["company_closing_balance"];
    $vendor_opening_balance = $_POST["vendor_opening_balance"];
    $vendor_closing_balance = $_POST["vendor_closing_balance"];
    $category = $sql_object->get_vendor_category($vendor_code);
    $start_period = date("Y-m-d", strtotime($_POST["start_period"]));
    $end_period = date("Y-m-d", strtotime($_POST["end_period"]));
    $status = 0;
    $time_stamp = date('Y-m-d H:i:s');
    //Vendor CSV Upload
    $fileName = $_FILES["vendor_file"]["tmp_name"];
    $status=0;
    $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    if (isset($_FILES['vendor_file']['name']) && in_array($_FILES['vendor_file']['type'], $file_mimes)) {
        $vendor_file = fopen($fileName, "r");
        $flag = true;
        $k=1;
        $arr_file = explode('.', $_FILES['vendor_file']['name']);
        $extension = end($arr_file);
     
        if('csv' == $extension) {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
 
        $spreadsheet = $reader->load($_FILES['vendor_file']['tmp_name']);
 
        $sheetData = $spreadsheet->getActiveSheet()->toArray();
        if (!empty($sheetData)) {
            for ($i=1; $i<count($sheetData); $i++) {
            $date = "";
            if (isset($sheetData[$i][0])) {
                $sheet_date = mysqli_real_escape_string($sql_object->con, $sheetData[$i][0]);
                if (strpos($sheet_date, '/') != false) {$old_date = explode('/', $sheet_date); }
                else if (strpos($sheet_date, '-') != false) {$old_date = explode('-', $sheet_date); }
                else if (strpos($sheet_date, '.') != false) {$old_date = explode('.', $sheet_date); }
                $date = $old_date[2].'-'.$old_date[1].'-'.$old_date[0];
            }
            $particular = "";
            if (isset($sheetData[$i][1])) {
                $particular = mysqli_real_escape_string($sql_object->con, $sheetData[$i][1]);
            }
            $document_type = "";
            if (isset($sheetData[$i][2])) {
                $document_type = mysqli_real_escape_string($sql_object->con, $sheetData[$i][2]);
            }
            $invoice_no = "";
            if (isset($sheetData[$i][3])) {
                $invoice_no = trim(mysqli_real_escape_string($sql_object->con, $sheetData[$i][3]));
            }
            $debit = "";
            if (isset($sheetData[$i][4])) {
                $debit = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][4]);
            }
            $credit = "";
            if (isset($sheetData[$i][5])) {
                $credit = (float)mysqli_real_escape_string($sql_object->con, $sheetData[$i][5]);
            }
            $token_id=$k;
            $sqlInsert = array('date'=>$date,'particular'=>$particular, 'document_type'=>$document_type, 
            'invoice_no'=>$invoice_no, 'debit'=>$debit, 'credit'=>$credit, 'upload_id'=>$upload_id, 'token_id'=>$token_id,'status'=>$status, 'time_stamp'=>$time_stamp,'company_name'=>$company_name, 'company_code'=>$company_code,'vendor_name'=>$vendor_name , 'vendor_code'=>$vendor_code ,'category'=>$category);
            if($sql_object->insert('vendor_data', $sqlInsert)){ //echo "1";
             } 
            $k++;
        }
    }
}
?>