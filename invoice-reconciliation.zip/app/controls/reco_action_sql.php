<?php 
require_once('common.php');
$sql_object = new common ();
$sql_object->update_bi_table();
// Action to be check as every time error is comming.. while rico with ketan
$action = mysqli_real_escape_string($sql_object->con, $_POST['action']);
$save_statement_action_text = mysqli_real_escape_string($sql_object->con, $_POST['save_statement_action_text']);
$matching_amount_check = mysqli_real_escape_string($sql_object->con, $_POST['matching_amount_check']);
$upload_id = mysqli_real_escape_string($sql_object->con, $_POST['upload_id']);
if($save_statement_action_text == "PM"){ $remark = 'PM';} else{$remark = 'UM';}
//below data are in array
$matching_id = uniqid();
if(isset($_POST['sap_check'])){
   $sap_sr_no = $_POST['sap_check'];
   $len = sizeof($sap_sr_no);
   for ($i=0; $i < $len; $i++) {
      if(ISSET($_POST['sap_reason_'.$sap_sr_no[$i]])){
      $sap_reason = $_POST['sap_reason_'.$sap_sr_no[$i]]; 
      $sap_user_action = $_POST['sap_action_'.$sap_sr_no[$i]]; 
      $sap_comment = $_POST['sap_comment_'.$sap_sr_no[$i]]; 
      $sap_amount = $_POST['sap_amount_'.$sap_sr_no[$i]];
      //$sap_reason_count = $_POST['sap_reason_count'][$i]; 
      $sap_reason_count = sizeof($sap_reason);
      for ($j=0; $j < $sap_reason_count; $j++) {
         if($matching_amount_check != 0){
         $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`, `statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`, `date_time`) VALUES ('$sap_sr_no[$i]','$upload_id','sap_data','$sap_amount[$j]','$sap_comment[$j]','$sap_user_action[$j]','$sap_reason[$j]','$remark','$current_date_time')";
           mysqli_query($sql_object->con, $query_insert) or die(mysqli_error($sql_object->con));
        }
      }
      //update sap data
      $query = "UPDATE `sap_data` SET comment = 'AT',match_type = 'MM' where sr_no = $sap_sr_no[$i] ";  
      mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
   }
      //Manual Match Entries
    if($save_statement_action_text == "UM" AND $matching_amount_check == 0){
         $insert_sap = array('statement_no' => $sap_sr_no[$i], 'statement_type' => 'sap_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
         $sql_object->insert('manual_match', $insert_sap);
         $query = "UPDATE `sap_data` SET match_type = 'MM' where sr_no = $sap_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
      }

       //Thrash Hold Limit uptro 5 Rs Entries
    if($save_statement_action_text == "UM" AND $matching_amount_check < 6){
         $insert_sap = array('statement_no' => $sap_sr_no[$i], 'statement_type' => 'sap_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
         $sql_object->insert('manual_match', $insert_sap);
         $query = "UPDATE `sap_data` SET match_type = 'MM' where sr_no = $sap_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
      }

   // Reverse Entries 
      if($save_statement_action_text == "PM" AND $matching_amount_check == 0 AND !isset($_POST['vendor_check'])){ 
         for ($i=0; $i < $len; $i++) {
            $insert_sap = array('statement_no' => $sap_sr_no[$i], 'statement_type' => 'sap_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => 'RE' );
         $sql_object->insert('manual_match', $insert_sap);
            $query = "UPDATE `sap_data` SET match_type = 'RE', comment = 'AT', status = 1 where sr_no = $sap_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
 
         }
      }
      // 0 in PM
      if($save_statement_action_text == "PM" AND $matching_amount_check == 0 AND isset($_POST['vendor_check'])){ 
         for ($i=0; $i < $len; $i++) {
            $insert_sap = array('statement_no' => $sap_sr_no[$i], 'statement_type' => 'sap_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => 'PM0' );
         $sql_object->insert('manual_match', $insert_sap);
            $query = "UPDATE `sap_data` SET match_type = 'MM', comment = 'AT', status = 1 where sr_no = $sap_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
 
         }
      }
   } 
}

if(isset($_POST['vendor_check'])){
   $vendor_sr_no = $_POST['vendor_check'];
   $len = sizeof($vendor_sr_no);
   for ($i=0; $i < $len; $i++) {
      if(isset($_POST['vendor_reason_'.$vendor_sr_no[$i]])){
      $vendor_reason = $_POST['vendor_reason_'.$vendor_sr_no[$i]]; 
      $vendor_user_action = $_POST['vendor_action_'.$vendor_sr_no[$i]]; 
      $vendor_comment = $_POST['vendor_comment_'.$vendor_sr_no[$i]]; 
      $vendor_amount = $_POST['vendor_amount_'.$vendor_sr_no[$i]];
      //$vendor_reason_count = $_POST['vendor_reason_count'][$i]; 
      $vendor_reason_count = sizeof($vendor_reason);
      for ($j=0; $j < $vendor_reason_count; $j++) {
         if($matching_amount_check != 0){
            if($save_statement_action_text == "PM"){$attached_stmt =  $sap_sr_no[$i]; } else { $attached_stmt = 0; }
         $query_insert = "INSERT INTO `reco_summary_amount`(`statement_no`,`upload_id`, `statement_type`, `amount`, `comment`, `action_by`, `reason`, `remark`,`attached_stmt`, `date_time`) VALUES ('$vendor_sr_no[$i]','$upload_id','vendor_data','$vendor_amount[$j]','$vendor_comment[$j]','$vendor_user_action[$j]','$vendor_reason[$j]','$remark','$attached_stmt','$current_date_time')";
            mysqli_query($sql_object->con, $query_insert) or die(mysqli_error($sql_object->con));

         }
      }
      //update vendor data
      $query = "UPDATE `vendor_data` SET comment = 'AT',remark_dev = 'MM' where sr_no = $vendor_sr_no[$i] ";  
      mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
      //update vendor data
      if($save_statement_action_text == "PM"){
      $query = "UPDATE `sap_data` SET comment = 'AT',match_type = 'MM' where match_id = $vendor_sr_no[$i] ";  
      mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
   }  
}
      //Manual Match Entries
    if($save_statement_action_text == "UM" AND $matching_amount_check == 0){
      $insert_sap = array('statement_no' => $vendor_sr_no[$i], 'statement_type' => 'vendor_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
         $sql_object->insert('manual_match', $insert_sap);
         $query = "UPDATE `vendor_data` SET remark_dev = 'MM' where sr_no = $vendor_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
      }

       //Thrash Hold Limit upto 5 Rs Entries
    if($save_statement_action_text == "UM" AND $matching_amount_check < 6){
      $insert_sap = array('statement_no' => $vendor_sr_no[$i], 'statement_type' => 'vendor_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => '' );
         $sql_object->insert('manual_match', $insert_sap);
         $query = "UPDATE `vendor_data` SET remark_dev = 'MM' where sr_no = $vendor_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
      }

      //PM 0 Entries
      if($save_statement_action_text == "PM" AND $matching_amount_check == 0){ 
         for ($i=0; $i < $len; $i++) {
            $insert_sap = array('statement_no' => $vendor_sr_no[$i], 'statement_type' => 'vendor_data', 'matching_id' => $matching_id, 'upload_id' => $upload_id, 'date_time' => $current_date_time, 'flag' => 0, 'remark_dev' => 'PM0' );
         $sql_object->insert('manual_match', $insert_sap);
            $query = "UPDATE `vendor_data` SET remark_dev = 'MM', comment = 'AT', status = 1 where sr_no = $sap_sr_no[$i] ";  
            mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object->con));
 
         }
      }
   }
}
echo $remark;
?>