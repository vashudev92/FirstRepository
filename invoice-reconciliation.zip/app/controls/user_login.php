<?php  
	require_once('common.php');
	$sql_object = new common ();
	$user_name = mysqli_real_escape_string($sql_object->con, $_POST['user_name_login']);  
    $password = mysqli_real_escape_string($sql_object->con, $_POST['user_password_login']); 
      $login = $sql_object->login($user_name,$password);  
      if($login){  
         echo "1";  
         //echo $login;
      }
      else
      {  
         echo "0";  
      }
?>