<?PHP 
    // session_start();
     set_time_limit(500);
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	date_default_timezone_set('Asia/Calcutta');
	// $mysql = mysqli_connect("localhost", "root", "", "welspun_recotool") or die(mysqli_error());
	// if ($mysql->connect_error) {
    // die('Connect Error: ' . $mysql->connect_error); }
 	$current_date_time=date('Y-m-d H:i:s'); //mysql format with date 
	$current_date=date('Y-m-d'); //mysql format with Current date 
     class Databases{  
      public $con;  
      public $error;  
      public function __construct()  
      {  
           $this->con = mysqli_connect("localhost:3307", "root", "", "welspun_recotool1");  
           if(!$this->con)  
           {  
                echo 'Database Connection Error ' . mysqli_connect_error($this->con);  
           }  
      }  
      public function insert($table_name, $data)  
      {  
           $string = "INSERT INTO ".$table_name." (";            
           $string .= implode(",", array_keys($data)) . ') VALUES (';            
           $string .= "'" . implode("','", array_values($data)) . "')";
           if(mysqli_query($this->con, $string))  
           {  
                return true;  
           }  
           else  
           {  
                echo mysqli_error($this->con);  
           }  
           mysqli_close($this->con);
      }
      public function select($table_name,$where_colum,$where_value)  
      {  
           $array = array();
           if($where_colum != ''){
                    $where = "where ".$where_colum." = '".$where_value."'";
               }else{
                    $where='';
               }  
           $query = "SELECT * FROM ".$table_name." ".$where;  
           $result = mysqli_query($this->con, $query);  
           while($row = mysqli_fetch_assoc($result))  
           {  
                $array[] = $row;  
           }  
           return $array;  
           mysqli_close($this->con);
      }   
      public function update($table_name, $fields, $where_condition)  
      {  
           $query = '';  
           $condition = '';  
           foreach($fields as $key => $value)  
           {  
                $query .= $key . "='".$value."', ";  
           }  
           $query = substr($query, 0, -2);  
           /*This code will convert array to string like this-  
           input - array(  
                'key1'     =>     'value1',  
                'key2'     =>     'value2'  
           )  
           output = key1 = 'value1', key2 = 'value2'*/  
           foreach($where_condition as $key => $value)  
           {  
                $condition .= $key . "='".$value."' AND ";  
           }  
           $condition = substr($condition, 0, -5);  
           /*This code will convert array to string like this-  
           input - array(  
                'id'     =>     '5'  
           )  
           output = id = '5'*/  
           return $query = "UPDATE ".$table_name." SET ".$query." WHERE ".$condition."";  
           if(mysqli_query($this->con, $query))  
           {  
                return true;  
           }  
      } 
      public function delete_query($table_name, $where_condition) 
          {  
               $condition = ''; 
            foreach($where_condition as $key => $value)  
            {  
                $condition .= $key . "='".$value."' AND ";  
            }  
            $condition = substr($condition, 0, -5); 
            $query = "delete from ".$table_name." where ".$condition; 
            if(mysqli_query($this->con, $query))  
            {  
                return true;  
            }  
            mysqli_close($this->con);
         }
     public function check_session(){
          if(ISSET($_SESSION['login'])){

          }
          else{
               //header("Location: login.php");
               echo("<script>location.href = 'login.php';</script>");
               exit();
          }
     }

 } 
	
?>