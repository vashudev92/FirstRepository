<?php 
require_once('../controls/common.php');
    $sql_object = new common ();
$token = $_POST['token'];
$click = $_POST['click'];
        $unmantch = abs($sql_object -> match_record($token,'ALL') - ($sql_object -> match_record($token,'PM') + $sql_object -> match_record($token,'FM')));
        ?>
        <input type="hidden" name="" id="button_color" value="<?php echo $click; ?>">
        <span id="btn_all" onclick="get_matching_table('all','<?php echo $token; ?>');" class="badge bg-primary pointer" style="cursor: pointer;">All Record <?php  echo $sql_object -> match_record($token,'ALL'); ?></span>
        <span id="btn_fullmatch" onclick="get_matching_table('FM','<?php echo $token; ?>');" class="badge text-success pointer" style="cursor: pointer;">Matched: <?php  echo $sql_object -> match_record($token,'FM'); ?> </span>
        <span id="btn_partialmatch" onclick="get_matching_table('PM','<?php echo $token; ?>');" class="badge text-warning pointer" style="cursor: pointer;">Partial Matched: <?php  echo $sql_object -> match_record($token,'PM'); ?> </span>
        <span id="btn_unmatch" onclick="get_matching_table('UM','<?php echo $token; ?>');" class="badge text-danger pointer" style="cursor: pointer;">Unmatch: <?php  //echo $unmantch; 
        echo $sql_object -> match_record($token,' ') + $sql_object -> match_record($token,'UM'); ?></span>
        <span id="btn_manualmatch" onclick="get_matching_table('MM','<?php echo $token; ?>');" class="badge text-info pointer" style="cursor: pointer;">Manual Match: <?php echo $sql_object -> match_record($token,'MM'); ?></span> 
       <span id="btn_summary" onclick="get_matching_table('SUM','<?php echo $token; ?>');" class="badge text-dark pointer" style="cursor: pointer;">Summary<?php  //echo $sql_object -> match_record($token,'UM');; ?></span>
        
        <span id="btn_summary" onclick="get_PM_UM_data('<?php echo $token; ?>');" class="badge rounded-pill bg-light text-dark pointer" style="cursor: pointer;">(PM + UM)</span>

<script type="text/javascript">
  var a = $("#button_color").val();
  if(a =='all'){
      $("#btn_all").addClass("bg-primary");$("#btn_all").removeClass("text-primary");
      $("#btn_fullmatch").addClass("text-success");$("#btn_fullmatch").removeClass("bg-success");
      $("#btn_partialmatch").addClass("text-warning");$("#btn_partialmatch").removeClass("bg-warning");
      $("#btn_unmatch").addClass("text-danger");$("#btn_unmatch").removeClass("bg-danger");
      $("#btn_manualmatch").addClass("text-info");$("#btn_manualmatch").removeClass("bg-info");
      $("#btn_summary").addClass("text-dark");$("#btn_summary").removeClass("bg-dark");
      $("#display_block").text("All Records");
    }
    else if(a=='FM'){
      //alert(a);
      $("#btn_fullmatch").addClass("bg-success");$("#btn_fullmatch").removeClass("text-success");
      $("#btn_all").addClass("text-primary");$("#btn_all").removeClass("bg-primary");
      $("#btn_partialmatch").addClass("text-warning");$("#btn_partialmatch").removeClass("bg-warning");
      $("#btn_unmatch").addClass("text-danger");$("#btn_unmatch").removeClass("bg-danger");
      $("#btn_manualmatch").addClass("text-info");$("#btn_manualmatch").removeClass("bg-info");
      $("#btn_summary").addClass("text-dark");$("#btn_summary").removeClass("bg-dark");
      $("#display_block").text("Fully Matched Records");

    }
    else if(a=='PM'){
      $("#btn_partialmatch").addClass("bg-warning");$("#btn_partialmatch").removeClass("text-warning");
      $("#btn_all").addClass("text-primary");$("#btn_all").removeClass("bg-primary");
      $("#btn_fullmatch").addClass("text-success");$("#btn_fullmatch").removeClass("bg-success");
      $("#btn_unmatch").addClass("text-danger");$("#btn_unmatch").removeClass("bg-danger");
      $("#btn_manualmatch").addClass("text-info");$("#btn_manualmatch").removeClass("bg-info");
      $("#btn_summary").addClass("text-dark");$("#btn_summary").removeClass("bg-dark");
      $("#display_block").text("Partial Matched Records");
    }
    else if(a=='UM'){
      $("#btn_unmatch").addClass("bg-danger");$("#btn_unmatch").removeClass("text-danger");
      $("#btn_all").addClass("text-primary");$("#btn_all").removeClass("bg-primary");
      $("#btn_fullmatch").addClass("text-success");$("#btn_fullmatch").removeClass("bg-success");
      $("#btn_partialmatch").addClass("text-warning");$("#btn_partialmatch").removeClass("bg-warning");
      $("#btn_manualmatch").addClass("text-info");$("#btn_manualmatch").removeClass("bg-info");
      $("#btn_summary").addClass("text-dark");$("#btn_summary").removeClass("bg-dark");
      $("#display_block").text("Un-Matched Records");
    }
    else if(a=='MM'){
      $("#btn_manualmatch").addClass("bg-info");$("#btn_manualmatch").removeClass("text-info");
      $("#btn_all").addClass("text-primary");$("#btn_all").removeClass("bg-primary");
      $("#btn_fullmatch").addClass("text-success");$("#btn_fullmatch").removeClass("bg-success");
      $("#btn_partialmatch").addClass("text-warning");$("#btn_partialmatch").removeClass("bg-warning");
      $("#btn_unmatch").addClass("text-danger");$("#btn_unmatch").removeClass("bg-danger");
      $("#btn_summary").addClass("text-dark");$("#btn_summary").removeClass("bg-dark");
      $("#display_block").text("Manual Matched Records");
    }
    else if(a=='SUM'){
      $("#btn_summary").addClass("bg-dark");$("#btn_summary").removeClass("text-dark");
      $("#btn_all").addClass("text-primary");$("#btn_all").removeClass("bg-primary");
      $("#btn_fullmatch").addClass("text-success");$("#btn_fullmatch").removeClass("bg-success");
      $("#btn_partialmatch").addClass("text-warning");$("#btn_partialmatch").removeClass("bg-warning");
      $("#btn_unmatch").addClass("text-danger");$("#btn_unmatch").removeClass("bg-danger");
      $("#btn_manualmatch").addClass("text-info");$("#btn_manualmatch").removeClass("bg-info");
      $("#display_block").text("Summary of Records");
    }
</script>