<?php 
header('Content-type: application/json');
   require_once('../controls/common.php');
   $sql_object = new common ();
   $vendor_category = mysqli_real_escape_string($sql_object->con, $_POST['vendor_category']);
   $compoany_name = mysqli_real_escape_string($sql_object->con, $_POST['compoany_name']);
   $finincial_year = mysqli_real_escape_string($sql_object->con, $_POST['finincial_year']);
   $array =  array($sql_object->vendor_count($compoany_name,$vendor_category,$finincial_year),$sql_object->uploaded_vendor_count($compoany_name,$vendor_category,$finincial_year));
   echo json_encode($array);
?>