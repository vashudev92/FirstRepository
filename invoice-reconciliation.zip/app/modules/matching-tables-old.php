<?php 
use Phppot\DataSource;
if(ISSET($_POST['resource_id'])){
require_once('../../app/controls/common.php');
$sql_object = new common (); 
	$record_type = $_POST['resource_id'];
	$token = $_POST['token'];
}
else{
	$record_type = "all";
	$token = $_GET['token'];
}
?> 
<div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">WELSPUN RECORDS  || VENDOR RECORDS</h5>

              <!-- Default Table -->
              <table class="table rec-table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Doc. No / Posting Date</th>
                    <th scope="col">Doc.Type</th>
                    <th scope="col">Invoive No / Date</th>
                    <th scope="col">Amount</th>
                    <th scope="col">TDS</th>
                    <th scope="col">Status</th>
                    <th scope="col">Party</th>
                    <th scope="col" style="border-right: 2px solid;">Comment</th>
                     <th scope="col">#</th>
                    <th scope="col">Invoive No / Date</th>
                    <th scope="col">Doc.Type</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Amount Difference</th>
                    <th scope="col">Status</th>
                    <th scope="col">Party</th>
                    <th scope="col">Comment</th>
                  </tr>
                </thead>
                <tbody>
                <?php 
                    $i=0;
                    $sqlSelect = "select t1.date, t1.invoice_no, t2.document_date, t2.reference_no
from vendor_data t1, sap_data t2 where t1.date = t2.document_date and t1.invoice_no = t2.reference_no;";
                    echo $sqlSelect = "SELECT vendor_data.sr_no as v_sr_no,sap_data.sr_no,sap_data.sr_no,sap_data.tds,sap_data.document_date,vendor_data.date,sap_data.amount,sap_data.document_number,sap_data.document_type,sap_data.posting_date,vendor_data.date,vendor_data.credit,vendor_data.debit,sap_data.reference_no,vendor_data.invoice_no FROM `sap_data` INNER JOIN vendor_data ON sap_data.document_date = vendor_data.date and sap_data.reference_no = vendor_data.invoice_no  and sap_data.upload_id = '$token';";
                    $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));
                    foreach($post as $row) { 
                      $i++;
                ?>
                  <tr>
                    <th scope="row">
                      <div class="form-check">
                        <input class="form-check-input w_check_1" name="sap_check[]" type="checkbox" value="<?php echo $row['sr_no'];?>"
                        onclick='$("#trw-<?php  echo $row['sr_no']; ?>").toggleClass("highlight")' onchange='calculate_reco_amount("<?php  echo $row['amount']; ?>","welspun","",this,<?php  echo $row['sr_no']; ?>)'>
                        <label class="form-check-label" for="flexCheckDefault">
                          <?php  echo $i;//$row['sr_no']; ?>
                        </label>
                      </div>
                    </th>
                    <td><?php  echo $row['document_number']; ?><br><?php  echo date("d/m/Y", strtotime($row['posting_date'])); ?></td>
                    <td><?php  echo $row['document_type']; ?></td>
                    <td><?php  echo $row['reference_no']; ?><br><?php  echo date("d/m/Y", strtotime($row['document_date'])); ?></td>
                    <td>₹ <?php echo $row['amount']; ?></td>
                    <td><?php echo $row['tds']; ?></td>
                    <th>comment</th>
                    <th>Status</th>
                    <td style="border-right: 2px solid;">2016-05-25</td>
                    <th scope="row">
                      <?php  echo $i;//$row['v_sr_no']; ?>
                    </th>
                    <th><?php  echo $row['invoice_no']; ?> <br> <?php  echo date("d/m/Y", strtotime($row['date'])); ?></th>
                    <th><?php  echo $row['document_type']; ?></th>
                    <th>₹ <?php  if($row['debit'] != 0){ echo $row['debit']." (D)";} else { echo $row['credit']." (C)";} ?></th>
                    <th>Amount Difference</th>
                    <th>Status</th>
                    <th>Party</th>
                    <th>Comment</th>
                  <?php } ?>
                  </tr>
                </tbody>
              </table>
              <!-- End Default Table Example -->
            </div>
          </div>

        </div>

      </div>