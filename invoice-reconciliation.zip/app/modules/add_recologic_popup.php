<?php 
require_once('../../app/controls/common.php');
$sql_object = new common ();
$sr_no = mysqli_real_escape_string($sql_object->con, $_POST['sr_no']);
$action = mysqli_real_escape_string($sql_object->con, $_POST['action']);
if($action == "UPDATE"){
  $query = "SELECT * FROM master_mismatch_reason where sr_no = $sr_no ";
  $row = mysqli_query($sql_object->con, $query);
  $result = mysqli_fetch_assoc($row);
}
?>
              <div class="modal fade" id="add_recologic_popup" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <form id="modal_form">
                      <input type="hidden" name="action" value="<?php echo $action; ?>">
                      <input type="hidden" name="sr_no" value="<?php echo $sr_no; ?>">
                      <div class="modal-header">
                        <h5 class="modal-title">Add / Edit Reco Logic</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="col-12 mt-3">
                          <label for="inputNanme4" class="form-label">Logic Name:</label>
                          <input type="text" class="form-control" id="logic_name" name="logic_name" required value="<?php if($action == "UPDATE"){echo $result['reason'];}?>">
                        </div>
                        <div class="col-12 mt-2">
                          <label for="inputNanme4" class="form-label" >Logic Nature:</label>
                          <select class="form-select" aria-label="Default select example" id="logic_nature" name="logic_nature">
                            <option value="+" <?php if($action == "UPDATE" and $result['effect'] == '+'){ echo "selected";} ?> >Credit (+)</option>
                            <option value="-" <?php if($action == "UPDATE" and $result['effect'] == '-'){ echo "selected";} ?>>Debit (-)</option>
                          </select>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div><!-- End Basic Modal-->
<script type="text/javascript">
  $('#add_recologic_popup').modal({backdrop: 'static', keyboard: false})  
      $("#modal_form").on('submit',(function(e) {
  if(e.isDefaultPrevented())
  { }
  else
  {
      $("#submit").attr("disabled", true);
      $(".loader-layout").toggle();
      e.preventDefault();
      $.ajax({
      url: "app/controls/reco_logic_sql.php",
      type: "POST",            
      data: new FormData(this), 
      contentType: false,       
      cache:false,            
      processData:false,       
            success: function(data)  {
              //alert(data);
              if(data == "1"){ alert("Record Saved...");location.reload(); }
              else if(data == "2"){ alert("Record Updated...");location.reload(); }
              else {alert(data);}
              $(".loader-layout").toggle();
            }
      });
    }
}));
</script>