<!DOCTYPE html>
<html lang="en">
<?php session_start();
require_once('app/controls/common.php');
$sql_object = new common ();
$sql_object->check_session(); ?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - Welspun Incoive Reconcellation</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link href="assets/css/reco.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body <?php if(basename($_SERVER['PHP_SELF']) == 'invoice-reconciliation.php'){ echo 'class="toggle-sidebar"';}?>>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <!-- Loadder animation start-->
<div class="col-lg-12 loader-layout">
    <img src="assets/img/Hourglass.gif">
    <h6>Processing Your Request <br> Please Wait...</h6>
</div> 
  <!-- Loadder animation Ends-->
    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">WELSPUN</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <!-- <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div> --><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->
		
        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <!--<img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">-->
            <span class="d-none d-md-block dropdown-toggle ps-2">Welcome Admin</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <!-- <li class="dropdown-header">
              <h6>Reconciliation Tool</h6>
              <span>by Value Lab</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li> -->

            <li>
              <a class="dropdown-item d-flex align-items-center" href="login.php?q=logout">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <!-- <li class="nav-item">
        
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'vendor_reco_dashboard.php'){echo 'collapsed';}?>" href="vendor_reco_dashboard.php">
              <i class="bi bi-circle"></i><span>Dashboard</span>
            </a>
      </li> -->
	  <!-- End Dashboard Nav -->

     <!--  <li class="nav-heading">Modules</li> -->

      <li class="nav-item">
        <a class="nav-link" id="reco_menu" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#" aria-expanded="false">
          <i class="bi bi-layout-text-window-reverse"></i><span>Vendor Reconcilaition</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse show" data-bs-parent="#sidebar-nav" style="">
          <li>
            <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'index.php'){echo 'collapsed';}?>" href="AppHome">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
          </li>
           <li class="nav-item">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'upload-excel.php'){echo 'collapsed';}?>" href="Upload-Statement">
          <i class="bi bi-file-earmark-excel-fill"></i>
          <span>Upload Statement</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'uploaded-statement.php'){echo 'collapsed';} ?>" href="Uploaded-Statement">
          <i class="bi bi-columns"></i>
          <span>Reco</span>
        </a>
      </li>
      <li class="nav-item collapsed">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'reco_logic.php'){echo 'collapsed';}?>" href="RecoLogic">
          <i class="bi bi-columns"></i>
          <span>Reco Logic</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'vendor_list.php'){echo 'collapsed';}?>" href="Vendors">
          <i class="bi bi-columns"></i>
          <span>Vendor List</span>
        </a>
      </li>
          <!-- <li>
            <a href="#">
              <i class="bi bi-circle"></i><span>Reports</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Reco. Report</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Report Pending with us</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Report Pending with Vendor</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Open Reco</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>WIP Reco</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Completed Reco</span>
            </a>
          </li>
          <li>
            <a href="#" style="padding: 5px 0px 5px 55px;">
              <i class="bi bi-circle"></i><span>Pending for Approval</span>
            </a>
          </li> -->


        </ul>
      </li>

      <!-- <li class="nav-item">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'invoice-record.php'){echo 'collapsed';}?>" href="invoice-record.php">
          <i class="bi bi-card-list"></i>
          <span>Invoice Records</span>
        </a>
      </li>


      <li class="nav-item">
        <a class="nav-link <?php if(basename($_SERVER['PHP_SELF']) != 'pages-blank.php'){echo 'collapsed';} ?>" href="pages-blank.php">
          <i class="bi bi-file-earmark"></i>
          <span>Blank</span>
        </a>
      </li> -->

    </ul>

  </aside><!-- End Sidebar-->