﻿<?php 
use Phppot\DataSource;
if(ISSET($_POST['resource_id'])){
require_once('../../app/controls/common.php');
$sql_object = new common (); 
	$record_type = $_POST['resource_id'];
	$token = $_POST['token'];
}
else{
	$record_type = "all";
	$token = $_GET['token'];
}
?> 

<!-- Data table Module Starts-->
<?php if($record_type != 'MM' and $record_type != 'SUM') { ?>
<form id="matching_table_form">
<input type="hidden" name="button_margin" id="button_margin" value="30">
<input type="hidden" name="upload_id" value="<?php echo $token; ?>">
  <div class="row">
    <div class="<?php  if($record_type =="PM"){ echo "col-lg-5";} elseif($record_type =="UM"){ echo "col-lg-7";} else { echo "col-lg-6";}?>">
      <div class="card nomargin" style="border-radius: 0px;">
        <div class="card-body" style="padding: 0px 2px 10px 2px;">
        <h5 class="card-title" style="padding-bottom: 2px;margin-bottom: 0px;margin-left: 15px;">
                Welspun Statement(<i id="record_count_welspun"></i>)<input type="text" id="welspun_search_box" placeholder="Search" style="height: 20px;width: 150px;font-size: 11px;    right: 5px;
    position: absolute;top: 22px;"></h5>
        </div>
      </div>
    </div>
    <div class="<?php  if($record_type =="PM"){ echo "col-lg-7";} elseif($record_type =="UM"){ echo "col-lg-5";} else { echo "col-lg-6";}?> nopadding">
      <div class="card nomargin" style="border-radius: 0px;">
        <div class="card-body" style="padding: 0px 2px 10px 2px;">
            <div class="row">
            <div class="col-lg-6">
              <h5 class="card-title text-center" style="padding-bottom: 2px;margin-bottom: 0px;">Vendor Statement
                (<i id="record_count_vendor"></i>)<input type="text" id="vendor_search_box" placeholder="Search" style="height: 20px;width: 130px;font-size: 11px;    right: 5px;
    position: absolute;top: 22px;"></h5>
            </div>

              <div class="col-lg-6 float-end">
              <?php if($record_type == 'UM'  OR $record_type == 'PM') { ?><button type="submit" name ="unmatch" class="btn btn-dark btn-sm ms-4 mt-2" id=
              "save_reco">Save</button> <input type="hidden" name="save_statement_action" value="UM">
<input type="hidden" name="matching_amount_check" id="matching_amount_check" value="0"> 
<input type="hidden" name="save_statement_action_text" id="save_statement_action_text" value="<?php echo $record_type; ?>"> 
            <?php } ?>
            </div>
            </div>
        </div>
      </div>
    </div>
  </div>
      <div class="row">
        <div class="<?php  if($record_type =="PM"){ echo "col-lg-5";} elseif($record_type =="UM"){ echo "col-lg-7";} else { echo "col-lg-6";}?> tableFixHead">
          <div class="card">
            <div class="card-body" style="padding: 0px 2px 20px 2px;">
      
              <!-- Table with stripped rows -->
              <table class="table rec-table table-bordered" id="welspun_table">
                <thead>
                  <tr class="border" style="height: 50px;border-top: 1px solid #e6e9ec !important;border-collapse: collapse !important;">
                    <th scope="col">
                    	<div class="form-check">
											  <input class="form-check-input" type="checkbox" onclick="welspun_check_all('w_check_1')" id="checkbox1">
											  <label class="form-check-label" for="flexCheckDefault">
											    #
											  </label>
											</div>
                    </th>
					<th scope="col">Doc. No /<br> Posting Date</th>
					<th scope="col">Doc.<br> Type</th>
                    <th scope="col">Invoive No /<br> Date</th>
                    <th scope="col">Amount</th>
                    <th scope="col">TDS<br><h6 class="text-end" id="tds_total" style="font-size: 11px;
    font-weight: bold;"></h6></th>
                    <?php  if($record_type =="UM"){ ?>
                    <th scope="col" style="width:90px">.</th>
                    <th scope="col" style="width:90px">Action</th>
                    <th scope="col" ></th><?php } ?>
					<!--<?php if($resource_id != 'match') { ?><th scope="col">Close Record</th><?php } ?>-->
                  </tr>
                </thead>
                <tbody>
								<?php
										$i=0;$tds_total = 0;
			            	if($record_type == 'all'){$query = "SELECT * FROM  sap_data where upload_id = '$token'  ORDER BY document_number ASC";}
                   // elseif($record_type == 'PM'){$query = "SELECT * FROM  sap_data where upload_id = '$token' and match_type='$record_type' and reference_no <> '' ORDER BY document_number ASC";}
			            	else{ $query = "SELECT * FROM  sap_data where upload_id = '$token' and match_type='$record_type' and comment != 'AT' ORDER BY reference_no DESC";}
			            	$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object));  
            				foreach($result as $row) {
                        $tds_total = $tds_total + $row['tds'];
            					  $i++;
					            	if($row['match_type'] == 'FM'){$clr_verify = 'table-success';}
				            		elseif($row['match_type'] == 'PM'){$clr_verify = 'table-warning';}
			            			elseif($row['match_type'] == 'UM'){$clr_verify = 'table-danger';}
                        elseif($row['match_type'] == 'MM'){$clr_verify = 'table-info';}
								?>
                  <tr class="<?php echo $clr_verify; ?>" id="trw-<?php  echo $row['sr_no']; ?>" style="border-top: 1px solid #e6e9ec !important;border-collapse: collapse !important; <?php if($row['match_type'] == 'PM') { echo 'height: 70px;';} ?>" >
                    <td scope="row">
                    	<div class="form-check">
                    		<?php if($record_type != 'all' AND $row['match_type'] != 'FM'){?>
											  <input class="form-check-input w_check_1" name="sap_check[]" type="checkbox" value="<?php echo $row['sr_no'];?>" id="sap_check_<?php echo $row['sr_no'];?>" 
											  onclick='$("#trw-<?php  echo $row['sr_no']; ?>").toggleClass("highlight")' onchange='calculate_reco_amount("<?php  echo $row['amount']; ?>","welspun","",this,<?php  echo $row['sr_no']; ?>)'>
											<?php } ?>
											  <label class="form-check-label" for="flexCheckDefault">
											    <?php  echo $i;//$row['token_id']; ?>
											  </label>
                        <input type="hidden" name="sap_reason_count[]" value="0" id = "sap_reason_count_<?php  echo $row['sr_no']; ?>">
											</div>
                    </td>
					<td><?php  echo $row['document_number']; ?><br><?php  echo date("d/m/Y", strtotime($row['posting_date'])); ?></td>
					<td><?php  echo $row['document_type']; ?></td>
                    <td><?php  echo $row['reference_no']; ?><br><?php  echo date("d/m/Y", strtotime($row['document_date'])); ?></td>
                    <td class="text-end">₹ <?php echo $row['amount']; ?>/-</td>
                    <td class="text-end">₹ <?php echo $row['tds']; ?>/-</td>
                  <?php  if($record_type =="UM"){ ?>
         <td class="sap-<?php  echo $row['sr_no']; ?>">
            <select class="" style="width: 100%;height: 25px;" id="sap_reason_<?php  echo $row['sr_no']; ?>" disabled name="sap_reason_<?php  echo $row['sr_no']; ?>[]" aria-label="Floating label select example" onchange="check_thrashhold_limit(this)">
            <!-- <option value="0" >Select Reason</option> -->
            <?php $query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['sr_no']; ?>" ><?php echo $result_reason['reason']; ?></option>
            <?php } ?>
          </select>
            <input type="text" autocomplete="off" disabled value="" class="" style="margin-top: 5px; width: 100%;height: 25px;padding-bottom: 0.5em;margin-bottom: 5px;" placeholder="comment" required
                id="sap_comment_<?php  echo $row['sr_no']; ?>" name="sap_comment_<?php  echo $row['sr_no']; ?>[]">
            </input> 
        </td>
        <td class="sap2-<?php  echo $row['sr_no']; ?>">
          <select class="" style="width: 100%;height: 25px;" id="sap_action_<?php  echo $row['sr_no']; ?>" disabled name="sap_action_<?php  echo $row['sr_no']; ?>[]" aria-label="Floating label select example">
            <!-- <option value="0" <?php if($row['action'] == 0){echo "selected"; } ?> >Action Required by.</option> -->
            <option value="2" <?php if($row['action'] == 2){echo "selected"; } ?> >Welspun</option>
            <option value="1" <?php if($row['action'] == 1){echo "selected"; } ?> >Vendor</option>
          </select>
          <input type="text" autocomplete="off" disabled value="<?php echo $row['amount']; ?>" class="" style="margin-top: 5px; width: 100%;height: 25px;padding-bottom: 0.5em;margin-bottom: 5px;" placeholder="Amount"
                id="sap_amount_<?php  echo $row['sr_no']; ?>" name="sap_amount_<?php  echo $row['sr_no']; ?>[]" required>
            </input> 
          </td>
          <td class="sap3-<?php  echo $row['sr_no']; ?>">           
            <button disabled="" type="button" id="sap_append_<?php  echo $row['sr_no']; ?>" name="sap_append" class="btn btn-dark btn-sm nopadding nomargin vendor_save_button" style="padding: 0px 4px !important;
    border-radius: 0px;margin-bottom: 5px;margin-top: 30px !important;" onclick="append_comments_fields('<?php  echo $row['sr_no']; ?>','sap','<?php  echo $row['amount']; ?>')"><i class="bi bi-file-earmark-plus"></i></button>
        </td>
      <?php } ?>
                  </tr>
				 <?php } ?>
                </tbody>
              </table>
              <?php //echo $i; ?>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>
		<!-- Uploaded Invoice -->
		<div class="<?php  if($record_type =="PM"){ echo "col-lg-7";} elseif($record_type =="UM"){ echo "col-lg-5";} else { echo "col-lg-6";}?> tableFixHead">
          <div class="card">
            <div class="card-body" style="padding: 0px 2px 20px 2px;">

              <!-- Table with stripped rows -->
              <table class="table rec-table table-bordered" id="vendor_table">
                <thead>
                  <tr class="border"  style="height: 50px;">
                    <th scope="col">
                    	<div class="form-check">
											  <input class="form-check-input" type="checkbox" value="" onclick="welspun_check_all('v_check_1')">
											  <label class="form-check-label" for="flexCheckDefault">
											    #
											  </label>
											</div>
                    </th>
                    <th scope="col">Invoice. No / <br> Date</th>
										<th scope="col">Doc.<br>Type</th>
                    <th scope="col">Amount</th>
                    <?php  if($record_type =="PM"){ ?>
                    <th scope="col" style = "border-left: 1px solid;width: 75px;">Amt. diff
                      <h6 class="text-end" id="amt_diff_total" style="font-size: 11px;font-weight: bold;"></h6>
                    </th>
                    <?php } ?>
                    <?php  if($record_type =="UM" OR $record_type =="PM"){ ?>
                    <th scope="col" style = "width: 100px;">.</th>
                    <th scope="col" style = "width: 100px;">Action</th>
                    <th scope="col" style = "width: 30px;"></th>
                  <?php } ?>
                  </tr>
                </thead>
                <tbody>
				
				<?php
                    $j=0;
                    $amt_diff_total = 0;
			            	$query = "SELECT * FROM  vendor_data where upload_id = '$token' ORDER BY `invoice_no` DESC";
			            	$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
			            	foreach($result as $row) {
                      //$j++;
			            		$match_id = $row['sr_no'];
			            		$query_sap = "SELECT * FROM  sap_data where match_id = '$match_id'  and reference_no <> ''";
				            	$row_sap = mysqli_query($sql_object->con, $query_sap) or die(mysqli_error($sql_object));  
				            	$post_post = mysqli_fetch_assoc($row_sap);
				            	if($row['remark_dev'] == 'MM' AND $record_type != 'all'){continue;}
				            	if (!empty($post_post)){ 	$w_amount = $post_post['amount'];
													$match_type = $post_post['match_type'];} 
				            	else{		$w_amount = 0;
		            				$match_type = "UM";}
			            		if($match_type == 'FM'){$clr_verify = 'table-success';$j++;}
		            			elseif($match_type == 'PM'){$clr_verify = 'table-warning';$j++;}
	            				elseif($match_type == 'UM'){$clr_verify = 'table-danger';$j++;}
                      elseif($match_type == 'MM'){$clr_verify = 'table-info';}
                      elseif($record_type == 'RE'){$j++;}
	            				if($record_type == 'all'){}  elseif($record_type != $match_type){$j--;continue;}
				?>
                  <tr class="<?php echo $clr_verify; ?>" id="trv-<?php  echo $row['sr_no']; ?>" >
                    <td scope="row">
                    	<div class="form-check">
                    		<?php 
                          $sr_no = $row['sr_no'];
                        if($record_type != 'all' AND $match_type != 'FM'){?>
                    			<?php if($row['debit'] != 0){ $v_amount = $row['debit'];$v_type = "debit";} 
														else { $v_amount =  $row['credit']; $v_type = "credit";} 
                    			?>
											  <input name="vendor_check[]" class="form-check-input v_check_1 vendor_checkbox <?php  echo $v_amount; ?>"  value="<?php echo $match_id;?>" id="vendor_check_<?php echo $row['sr_no'];?>"
											  type="checkbox" onclick='$("#trv-<?php  echo $row['sr_no']; ?>").toggleClass("highlight")' 
											   onchange='calculate_reco_amount("<?php  echo $v_amount; ?>","vendor","<?php  echo $v_type; ?>",this,"<?php  echo $sr_no; ?>")' >
											  <?php } ?>
											  <label class="form-check-label" for="flexCheckDefault">
											    <?php  echo $j;//$row['token_id']; ?>
                          <input type="hidden" name="vendor_reason_count[]" value="0" id = "vendor_reason_count_<?php  echo $row['sr_no']; ?>">
											  </label>
											</div>
                    </td>
                    <td><?php  echo $row['invoice_no']; ?> <br> <?php  echo date("d/m/Y", strtotime($row['date'])); ?></td>
					<td><?php  echo $row['document_type']; ?></td>
          <td>₹ <?php  if($row['debit'] != 0){ echo $row['debit']." (D)";$vendor_amount  = $row['debit'];} else { echo $row['credit']." (C)";$vendor_amount  = $row['credit'];} ?></td>
          <?php  if($record_type =="PM"){ ?>
          <td class="text-end" style = "border-left: 1px solid;">
          <?php
            if($clr_verify =="table-warning"){
            if($row['debit'] != 0){ echo "<span class='text-danger'>₹ " . ($row['debit'] + $w_amount) ."</span>";
              $amt_diff_total = $amt_diff_total + ($row['debit'] + $w_amount);
              $temp_diff = $row['debit'] + $w_amount;
          } 
              else {echo "<span class='text-danger'>₹ ".($row['credit'] - $w_amount)."</span>";
                 $amt_diff_total = $amt_diff_total + ($row['credit'] - $w_amount);
                 $temp_diff = $row['credit'] - $w_amount;
            }   }?>
                          </td>
          <?php } if($record_type =="UM" OR $record_type =="PM"){ ?>
					
							<?php if($clr_verify =="table-warning" or $clr_verify =="table-danger") { ?>
								<td class="inc-<?php  echo $row['sr_no']; ?>">
						<select class="" style="width: 100%;height: 25px;" disabled id="vendor_reason_<?php  echo $row['sr_no']; ?>"  name="vendor_reason_<?php  echo $row['sr_no']; ?>[]" aria-label="Floating label select example" onchange="check_thrashhold_limit(this)">
            <!-- <option value="0"  >Select Reason</option> -->
            <?php $query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['sr_no']; ?>" ><?php echo $result_reason['reason']; ?></option>
            <?php } ?>
					</select>		
          <input type="text" autocomplete="off" value="" class="" style="width: 100%;height: 25px;padding-bottom: 0.5em;margin-top: 5px;margin-bottom: 5px;" placeholder="Comment" required
                disabled id="vendor_comment_<?php  echo $row['sr_no']; ?>" name="vendor_comment_<?php  echo $row['sr_no']; ?>[]">
            </input>
				</td>
				<td class="inc2-<?php  echo $row['sr_no']; ?>">
					<select class="" style="width: 100%;height: 25px;" disabled id="vendor_action_<?php  echo $row['sr_no']; ?>" name="vendor_action_<?php  echo $row['sr_no']; ?>[]" aria-label="Floating label select example">
            <!-- <option value="0" >Action Required by.</option> -->
            <option value="1" >Vendor</option>
            <option value="2"  >Welspun</option>
					</select>
          <input type="text" autocomplete="off" class="" style="width: 100%;height: 25px;padding-bottom: 0.5em;margin-top: 5px;margin-bottom: 5px;" placeholder="Amount"
                disabled id="vendor_amount_<?php  echo $row['sr_no']; ?>" name="vendor_amount_<?php  echo $row['sr_no']; ?>[]" value="<?php if($record_type =='PM'){ echo $temp_diff;} else {echo $vendor_amount;} ?>" required>
            </input>
					</td>
					<td class="inc3-<?php  echo $row['sr_no']; ?>">					 
                <button disabled type="button" id="append_<?php  echo $row['sr_no']; ?>" name="append" class="btn btn-dark btn-sm nopadding nomargin vendor_save_button" style="padding: 0px 4px !important;
    border-radius: 0px;margin-bottom: 5px;margin-top: 30px !important;" onclick="append_comments_fields('<?php  echo $row['sr_no']; ?>','inc','<?php if($record_type =='PM'){ echo $temp_diff;} else {echo $vendor_amount;} ?>')"><i class="bi bi-file-earmark-plus"></i></button>
              </div>
				</td>
				<?php } } else{ //echo "<td></td><td></td><td></td>";
      }?>
                  </tr>			 
				  <?php } ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>
      </div>
      <input name="action" id="action" value="SAP" type="hidden" />
 </form>
 <!-- Manual Matching Table Starts -->
<?php } elseif($record_type == 'MM') { ?>
					<div class="row">	
            <?php	  $query = "SELECT * FROM  manual_match where upload_id = '$token' group by matching_id";
			            	$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object));  
            				foreach($result as $row) {
            					$matching_id = $row['matching_id'];
            					?> 

        <div class="col-lg-6">
            	<table class="table rec-table">
                <thead>
                  <tr>
                  	<tr class="table-dark">
                    <td></td>
                    <td>Matching Id:</td>
                    <td class="text-uppercase"><?php echo $matching_id;?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  	<th scope="col">#</th>
                    <th scope="col">Statement</th>
                    <th scope="col">Invoice No / Date</th>
                    <th scope="col">Document No / Date</th>
                    <th scope="col">Amount</th>
                  </tr>
                </thead>
                <tbody>
            						
            					<?php
            					$query_match = "SELECT * FROM  manual_match where matching_id = '$matching_id'";
			            	  $result_match = mysqli_query($sql_object->con, $query_match) or die(mysqli_error($sql_object));  
            				  foreach($result_match as $row_match) { 
            				  	$statement_type = $row_match['statement_type'];
            				  	$statement_no = $row_match['statement_no'];
            				  	if($statement_type == 'sap_data'){
            				  	$query_record = "SELECT * FROM  sap_data where sr_no = '$statement_no'";  
						            $row_record = mysqli_query($sql_object->con, $query_record) or die(mysqli_error($sql_object->con));  
						            $result_record = mysqli_fetch_assoc($row_record);
            				  	?>
                  <tr class="table-info">
                    <td class=""><?php echo $result_record['token_id']; ?></td>
                    <td>Welspun<br><?php echo $result_record['document_type']; ?></td>
                    <td><?php  echo $result_record['reference_no']; ?><br><?php  echo date("d/m/Y", strtotime($result_record['document_date'])); ?></td>
                    <td><?php  echo $result_record['document_number']; ?><br><?php  echo date("d/m/Y", strtotime($result_record['posting_date'])); ?></td>
                    <td>₹ <?php echo $result_record['amount']; ?>/-</td>
                  </tr>
                <?php }
                	elseif($statement_type == 'vendor_data'){ 
            				  	$query_record = "SELECT * FROM  vendor_data where sr_no = '$statement_no'";  
						            $row_record = mysqli_query($sql_object->con, $query_record) or die(mysqli_error($sql_object->con));  
						            $result_record = mysqli_fetch_assoc($row_record);
            				  	?>
                  <tr class="table-info">
                    <td class=""><?php echo $result_record['token_id']; ?></td>
                    <td>Vendor<br><?php echo $result_record['document_type']; ?></td>
                    <td><?php  echo $result_record['invoice_no']; ?> <br> <?php  echo date("d/m/Y", strtotime($result_record['date'])); ?></td>
                    <td></td>
                    <td>₹ <?php  if($result_record['debit'] != 0){ echo $result_record['debit']." (D)";} else { echo $result_record['credit']." (C)";} ?></td>
                  </tr>
                	<?php } 
                 } ?>  
               </tbody>
              </table> 
        </div><?php }  ?>
               
<?php } elseif($record_type == 'SUM') { 
            $query = "SELECT * FROM  record_detail where upload_id = '$token'";  
            $row = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object));  
            $result = mysqli_fetch_assoc($row); 
  ?> 
  <div class="row">
    <div class="col-lg-12">
    <h5>RECONCILATION BETWEEN <?php echo $result['company_name']; ?>(<?php echo $result['company_code']; ?>) AND <?php echo $result['vendor_name']; ?> (<?php echo $result['vendor_code']; ?>)</h5><h6>from <?php echo date("d/m/Y", strtotime($result['stmt_start_date'])); ?> to <?php echo date("d/m/Y", strtotime($result['stmt_end_date'])); ?></h6>
    </div>
    
      <div class="col-4 row " >
            <div class="col-7">
              <h6 class= "nopadding nomargin" style="font-size: 12px;">Matched Records (<?php echo $sql_object -> match_record($token,'FM'); ?>) :</h6> 
            </div>
            <div class="col-5">
              <h6 class= "nomargin text-end" style="font-size: 12px;">₹ <span id=""><?php echo $sql_object -> match_record_amount($token,'FM'); ?></span>/-</h6> 
            </div>
            <div class="col-7">
              <h6 class= "nopadding nomargin" style="font-size: 12px;">Manual Matched (<?php echo $sql_object -> match_record($token,'MM'); ?>) :</h6> 
            </div>
            <div class="col-5">
              <h6 class= "nomargin text-end" style="font-size: 12px;">₹ <span id=""><?php echo $sql_object -> match_record_amount($token,'MM'); ?></span>/-</h6> 
            </div>
            <div class="col-7">
              <h6 class= "nopadding nomargin" style="font-size: 12px;">Partial-Matched (<?php echo $sql_object -> match_record($token,'PM'); ?>):</h6> 
            </div>
            <div class="col-5">
              <h6 class= "nomargin text-end" style="font-size: 12px;">₹ <span id=""><?php echo $sql_object -> match_record_amount($token,'PM'); ?></span>/-</h6> 
            </div>
            <div class="col-7">
<?php 
        $unmantch = abs($sql_object -> match_record($token,'ALL') - ($sql_object -> match_record($token,'PM') + $sql_object -> match_record($token,'FM')));
        ?>
              <h6 class= "nopadding nomargin" style="font-size: 12px;">Un-Matched Records (<?php echo $unmantch;//echo $sql_object -> match_record($token,'UM'); ?>):</h6> 
            </div>
            <div class="col-5">
              <h6 class= "nomargin text-end" style="font-size: 12px;">₹ <span id=""><?php echo $sql_object -> match_record_amount($token,'UM'); ?></span>/-</h6> 
            </div>
            <div class="col-7">
              <h6 class= "nopadding nomargin fw-bold" style="font-size: 12px;">All Records (<?php echo $sql_object -> match_record($token,'ALL'); ?>):</h6> 
            </div>
            <div class="col-5">
              <h6 class= "nomargin text-end fw-bold" style="font-size: 12px;">₹ <span id=""><?php echo $sql_object -> match_record_amount($token,'FM') + $sql_object -> match_record_amount($token,'MM') + $sql_object -> match_record_amount($token,'PM') + $sql_object -> match_record_amount($token,'UM'); ?></span>/-</h6>
            </div>
        </div>
        <div class="col-4"></div>
        <div class="col-4 row " >
          <div class="col-6 nopadding ">
            <h6 class= "nopadding nomargin">Balance as per <?php echo $result['company_name']; ?> :</h6> 
          </div>
          <div class="col-6 nopadding">
            <h6 class= "nomargin text-end">₹ <span id=""><?php echo $result['company_closing_balance']; ?></span>/-</h6> 
          </div>
          <div class="col-6 nopadding">
            <h6 class= "nopadding nomargin">Balance as per <?php echo $result['vendor_name']; ?> :</h6> 
          </div>
          <div class="col-6 nopadding">
            <h6 class= "nomargin text-end">₹ <span id=""><?php echo $result['vendor_closing_balance']; ?></span>/-</h6> 
          </div>
          <div class="col-6 nopadding border-top">
            <h6 class= "nopadding nomargin">Difference. Amount:</h6> 
          </div>
          <div class="col-6 nopadding border-top">
            <h6 class= "nomargin text-end">₹ <span id=""><?php echo $result['company_closing_balance'] + $result['vendor_closing_balance']; ?></span>/-</h6> 
          </div>
          <div class="col-6 nopadding border-top">
            <h6 class= "nopadding nomargin">Reco. Items:</h6> 
          </div>
          <div class="col-6 nopadding border-top">
            <h6 class= "nomargin text-end">₹ <span id="reco_amount_display"><?php echo $sql_object -> gaps_identified_amount_total($token); ?></span>/-</h6> 
          </div>
          <div class="col-6 nopadding border-top">
        <h6 class= "nopadding nomargin"></h6> 
      </div>
      <div class="col-6 nopadding border-top">
        <?php 
           $recon_result = $sql_object -> gaps_identified_amount_total($token) - 
            ($result['company_closing_balance'] + $result['vendor_closing_balance']);
            //$sql_object -> match_record_amount($token));
           if($recon_result == 0){echo '<span class="badge bg-success float-end"><i class="bi bi-check-circle me-1"></i>Rico Matched</span>';}
            else{echo '<span class="badge bg-danger float-end"><i class="bi bi-exclamation-octagon me-1"></i>Rico Not Matched</span>';}
        ?>
      </div>
      </div>
  </div>
            <table class="table table-bordered">
                <thead>
                  <tr>
              <th scope="col" style="font-size: 14px;">#<?php //echo $result['company_closing_balance'] - $result['vendor_closing_balance']; ?></th>
                    <th scope="col"  style="font-size: 14px;">Gaps Identified</th>
                    <th scope="col"  style="font-size: 14px;">Vendor</th>
                    <th scope="col"  style="font-size: 14px;">Welspun</th>
                    <th scope="col"  style="font-size: 14px;">Total Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            $w_amt = 0;
            $v_amt = 0;
            foreach($row_reason as $result_reason) { 
                $w_amt = $w_amt + (int)$sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']);
                $v_amt = $v_amt + (int)$sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']);
              ?>
              <tr>
                    <th style="padding: 0 0 0 0.5em;font-size: 13px;">A<?php echo $result_reason['sr_no']; ?></th>
                    <td style="padding: 0 0 0 0.5em;font-size: 13px;"><a href="gaps_list.php?token=<?php echo $token;?>&q=<?php echo $result_reason['sr_no']; ?>" target="_blank"><?php echo $result_reason['reason'].""; ?></a></td>
                    <td style="padding: 0 0 0 0.5em;font-size: 13px;">
                      ₹ <?php echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']); ?></td>
                    <td style="padding: 0 0 0 0.5em;font-size: 13px;">
                      ₹ <?php echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']); ?></td>
                    <td style="padding: 0 0 0 0.5em;font-size: 13px;">
                      ₹ <?php //echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],'BOTH'); 
                      // if($result_reason['effect'] == "+"){
                      //   echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']) - $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']);}
                      //   else {
                      //   echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']) + $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']);}

                      echo $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],1,$result_reason['effect']) + $sql_object -> gaps_identified_amount($token,$result_reason['sr_no'],2,$result_reason['effect']);
                      ?>
                        
                      </td>
                  </tr>
            <?php } ?> 
            <tr>
              <th></th>
              <th>Total:</th>
              <th>₹ <?php echo $v_amt?></th>
              <th>₹ <?php echo $w_amt?></th>
              <th>₹ <?php echo $v_amt + $w_amt?></th>
            </tr>
                </tbody>
              </table>

<?php } ?>
</div>

 <script>

   $("#matching_table_form").on('submit',(function(e) {
  if(e.isDefaultPrevented())
  { 
  }
    else
    {
    	$(".loader-layout").toggle();
e.preventDefault();
$.ajax({
url: "app/controls/reco_action_sql.php",
type: "POST",            
data: new FormData(this), 
contentType: false,       
cache:false,            
processData:false,       
success: function(data)  
{
  //alert(data);
  $(".loader-layout").toggle();
  if(data == 'UM'){$("#btn_unmatch").click();}
  else if(data == 'PM'){$("#btn_partialmatch").click();}
  else{ alert(data);}
  $("#pm_sr_no").val('');
  $("#um_sr_no").val('');
}
});
    }
}));

   // MIS MATCH calculation
   //calculate reco amount
function calculate_reco_amount(amount,stmt,type,obj,sr_no) {
  //alert(type);
  if(type == 'credit'){var amount = -amount;}
  var pm_sr_no = $("#pm_sr_no").val();
  var um_sr_no = $("#um_sr_no").val();
  //$(".vendor_checkbox").removeAttr("disabled");
  //$("."+Math.abs(amount)).removeAttr("disabled");
  if($(obj).is(":checked")){  
    //$("#vendor_search_box").val(amount);
    //$("#vendor_search_box").trigger();
    if(stmt == 'welspun'){$("#pm_sr_no").val(pm_sr_no + sr_no + ',');}
    else {$("#um_sr_no").val(um_sr_no + sr_no + ',');}
    $('#sap_reason_'+sr_no).prop('disabled', false); 
    $('#sap_action_'+sr_no).prop('disabled', false); 
    $('#sap_comment_'+sr_no).prop('disabled', false); 
    $('#sap_amount_'+sr_no).prop('disabled', false); 
    $('#sap_append_'+sr_no).attr("disabled", false);
    //
    $('#vendor_reason_'+sr_no).prop('disabled', false); 
    $('#vendor_action_'+sr_no).prop('disabled', false); 
    $('#vendor_comment_'+sr_no).prop('disabled', false); 
    $('#vendor_amount_'+sr_no).prop('disabled', false);
    $('#append_'+sr_no).attr("disabled", false);

  } else {
    
    //$("#vendor_search_box").val("");
    //$("#vendor_search_box").trigger();
    if(stmt == 'welspun'){var newValue = pm_sr_no.replace(sr_no+',', '');$("#pm_sr_no").val(newValue);}
    else {var newValue = um_sr_no.replace(sr_no+',', '');$("#um_sr_no").val(newValue);}
    
    $('#sap_reason_'+sr_no).prop('disabled', true);
    $('#sap_action_'+sr_no).prop('disabled', true); 
    $('#sap_comment_'+sr_no).prop('disabled', true);
    $('#sap_amount_'+sr_no).prop('disabled', true);
    $('#sap_append_'+sr_no).attr("disabled", true);
    //
    $('#vendor_reason_'+sr_no).prop('disabled', true);
    $('#vendor_action_'+sr_no).prop('disabled', true); 
    $('#vendor_comment_'+sr_no).prop('disabled', true);  
    $('#vendor_amount_'+sr_no).prop('disabled', true); 
    $('#append_'+sr_no).attr("disabled", true);
  }
  
  var wel_amount = parseInt($("#welspun_reco_amount").val());
  var ven_amount = parseInt($("#vendor_reco_amount").val());
  if(stmt == "welspun"){
    var wel_prev_amount = $("#welspun_reco_amount").val();
    if($(obj).is(":checked")){ var wel_amount = parseInt(wel_prev_amount) + parseInt(amount);}
    else { var wel_amount = parseInt(wel_prev_amount) - parseInt(amount);}
    $("#welspun_reco_amount").val(wel_amount);
    $("#welspun_reco_amount_display").html(wel_amount);
    var ven_prev_amount = parseInt($("#vendor_reco_amount").val());
  }
  else if(stmt == "vendor"){
    var ven_prev_amount = $("#vendor_reco_amount").val();
    if($(obj).is(":checked")){var ven_amount = parseInt(ven_prev_amount) + parseInt(amount);}
    else {var ven_amount = parseInt(ven_prev_amount) - parseInt(amount);}
    $("#vendor_reco_amount").val(ven_amount);
    $("#vendor_reco_amount_display").html(ven_amount);
    var wel_prev_amount = parseInt($("#welspun_reco_amount").val());
  }
  var recio_amount = wel_amount - (-ven_amount);
  $("#reco_amount").val(recio_amount);
  $("#matching_amount_check").val(recio_amount);
  $("#reco_amount_display").html(recio_amount);
  //if(recio_amount == 0){ $('#save_reco').prop('disabled', false);}
  //else { $('#save_reco').prop('disabled', true);}
}
// Record count for table header
$("#record_count_vendor").html(<?php echo $j;?>);
$("#record_count_welspun").html(<?php echo $i;?>);
$("#tds_total").html("₹ "+<?php echo $tds_total;?>);
$("#amt_diff_total").html("₹ "+<?php echo $amt_diff_total;?>);


//Apending New Records for comments
         function append_comments_fields(a,b,c){
          var button_margin = parseInt($("#button_margin").val()) + 7;
          if(b == 'inc'){var name = "vendor";} else {var name = "sap";}
          var rem_amt = $("#"+name+"_amount_"+a).val();
          var final_amount = parseInt(c) - parseInt(rem_amt);
        // $("#button_margin").val(button_margin);
        $("."+b+"-"+a).append('<div id="inc11'+a+'">\
                <select class="" style="width: 100%;height: 25px;" id='+name+'_reason"  name="'+name+'_reason_'+a+'[]" aria-label="Floating label select example">\
            <!--<option value="0">Select Reason</option>-->\
            <?php $query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['sr_no']; ?>" ><?php echo $result_reason['reason']; ?></option>\
            <?php } ?>
          </select>\
                <input type="text" value="" class="" style="width: 100%;height: 25px;padding-bottom: 0.5em;margin-top: 5px;margin-bottom: 5px;" placeholder="Comment" required id="'+name+'_comment" name="'+name+'_comment_'+a+'[]">\
                </div>\
                ');
        $("."+b+"2-"+a).append('<div id="inc22'+a+'">\
                <select class="" style="width: 100%;height: 25px;" id="'+name+'_action_<?php  echo $row['sr_no']; ?>" name="'+name+'_action_'+a+'[]" aria-label="Floating label select example">\
            <!-- <option value="0"  >Action Required by.</option> -->\
            <option value="1"  >Vendor</option>\
            <option value="2" >Welspun</option>\
          </select>\
          <input type="text" value="'+final_amount+'" class="" style="width: 100%;height: 25px;padding-bottom: 0.5em;margin-top: 5px;margin-bottom: 5px;" required placeholder="Amount"\
               id="'+name+'_amount" name="'+name+'_amount_'+a+'[]">\
            </input></div>\
                ');
        $("."+b+"3-"+a).append('<div id="inc33'+a+'">\
                <button type="button" onclick="remove_this('+a+')" class=" btn btn-danger btn-sm nopadding nomargin '+name+'_save_button" style="padding: 0px 4px !important;\
    border-radius: 0px;margin-top: '+button_margin+'px !important;" ><i class="bi bi-file-earmark-minus"></i></button></div>\
                ');
        var sap_reason_count = parseInt($("#sap_reason_count_"+a).val()) + 1;
        $("#sap_reason_count_"+a).val(sap_reason_count);
        //
        var vendor_reason_count = parseInt($("#vendor_reason_count_"+a).val()) + 1;
        $("#vendor_reason_count_"+a).val(vendor_reason_count);
        return false;
        }

   function remove_this(a) {
        $("#inc11"+a).remove();
        $("#inc22"+a).remove();
        $("#inc33"+a).remove();
        var sap_reason_count = parseInt($("#sap_reason_count_"+a).val()) - 1;
        $("#sap_reason_count_"+a).val(sap_reason_count);
        //
        var vendor_reason_count = parseInt($("#vendor_reason_count_"+a).val()) - 1;
        $("#vendor_reason_count_"+a).val(vendor_reason_count);
        return false;
        }

// datatable Initlization welspun
    $(document).ready(function() {
    oTable = $('#welspun_table').DataTable({
      "paging":   false,
      "info":     false,
      "ordering": false,
      "dom": 'lrt'
    });
} );

$('#welspun_search_box').keyup(function(){
      oTable.search($(this).val()).draw() ;
})

// datatable Initlization vendor
    $(document).ready(function() {
    pTable = $('#vendor_table').DataTable({
      "paging":   false,
      "info":     false,
      "responsive": true,
      "ordering": false,
      "dom": 'lrt'
    });
} );

$('#vendor_search_box').keyup(function(){
      pTable.search($(this).val()).draw() ;
})

//Prevent form submitting on poressing enter
$(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });

// get selected value of sap and vendor recors for checkboc checked
var array = $('#pm_sr_no').val().split(",");
var array_length = array.length - 1;
for (i=0;i < array_length;i++){
  //$("#sap_check_"+array[i]).click();
  $("#sap_check_"+array[i]).prop('checked', true);
  //alert(array[i]);
}

var array = $('#um_sr_no').val().split(",");
var array_length = array.length - 1;
for (i=0;i < array_length;i++){
  //$("#vendor_check_"+array[i]).click();
  $("#vendor_check_"+array[i]).prop('checked', true);
  //alert(array[i]);
}

// thrashold limit checking functioon
function check_thrashhold_limit(a) {
  var val = $(a).val();
  var amount = $("#reco_amount").val();
  if(val == 24){
    if(amount > 5 || amount < -5){ $('#save_reco').attr("disabled", true); 
    alert("Round-Off Thrashold Limit is 5 Rs (+/-)");
  } else{$('#save_reco').attr("disabled", false);}
  }
   else{$('#save_reco').attr("disabled", false);}
}
  </script>