<?php 
require_once('../../app/controls/common.php');
require '../../spreadsheet/vendor/autoload.php';
$sql_object = new common (); 
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$upload_id = $_GET["id"];
$spreadsheet = new Spreadsheet();
$spreadsheet->setActiveSheetIndex(0);
$fm_sheet = $spreadsheet->getActiveSheet()->setTitle('Fully Matched (Auto)');
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$fm_sheet->setCellValue('A1', "SAP DATA");
$fm_sheet->setCellValue('A2', "Sl. No");
$fm_sheet->setCellValue('B2', "Document. No");
$fm_sheet->setCellValue('C2', "Posting Date");
$fm_sheet->setCellValue('D2', "Document Type");
$fm_sheet->setCellValue('E2', "Invoice No");
$fm_sheet->setCellValue('F2', "Invoice Date");
$fm_sheet->setCellValue('G2', "Amount");
$fm_sheet->setCellValue('H2', "TDS");
//vendor
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$fm_sheet->setCellValue('J1', "Vendor DATA");
$fm_sheet->setCellValue('J2', "Sl. No");
$fm_sheet->setCellValue('K2', "Invoice No");
$fm_sheet->setCellValue('L2', "Invoice Date");
$fm_sheet->setCellValue('M2', "Document Type");
$fm_sheet->setCellValue('N2', "Debit");
$fm_sheet->setCellValue('O2', "Credit");
$query = "SELECT * FROM  sap_data where upload_id = '$upload_id' and match_type='FM' ORDER BY reference_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $fm_sheet->setCellValue('A'.($i+2), $i);
    $fm_sheet->setCellValue('B'.($i+2), $row['document_number']);
    $fm_sheet->setCellValue('C'.($i+2), date("d/m/Y", strtotime($row['posting_date'])));
    $fm_sheet->setCellValue('D'.($i+2), $row['document_type']);
    $fm_sheet->setCellValue('E'.($i+2), $row['reference_no']);
    $fm_sheet->setCellValue('F'.($i+2), date("d/m/Y", strtotime($row['document_date'])));
    $fm_sheet->setCellValue('G'.($i+2), $row['amount']);
    $fm_sheet->setCellValue('H'.($i+2), $row['tds']);  
    //Vendor Details
    $match_id = $row['match_id'];
    $query_sap = "SELECT * FROM  vendor_data where sr_no = '$match_id'";
    $row_sap = mysqli_query($sql_object->con, $query_sap) or die(mysqli_error($sql_object));  
    $post_post = mysqli_fetch_assoc($row_sap);
    $fm_sheet->setCellValue('J'.($i+2), $i);
    $fm_sheet->setCellValue('K'.($i+2), $post_post['invoice_no']);
    $fm_sheet->setCellValue('L'.($i+2), date("d/m/Y", strtotime($post_post['date'])));
    $fm_sheet->setCellValue('M'.($i+2), $post_post['document_type']);
    $fm_sheet->setCellValue('N'.($i+2), $post_post['debit']);
    $fm_sheet->setCellValue('O'.($i+2), $post_post['credit']); 
    $i++;
}

//
$spreadsheet->createSheet();
$spreadsheet->setActiveSheetIndex(1);
$mm_sheet = $spreadsheet->getActiveSheet()->setTitle('Manual Matched');
$mm_sheet->setCellValue('A1', "SAP DATA");
$mm_sheet->setCellValue('A2', "Sl. No");
$mm_sheet->setCellValue('B2', "Document. No");
$mm_sheet->setCellValue('C2', "Posting Date");
$mm_sheet->setCellValue('D2', "Document Type");
$mm_sheet->setCellValue('E2', "Invoice No");
$mm_sheet->setCellValue('F2', "Invoice Date");
$mm_sheet->setCellValue('G2', "Amount");
$mm_sheet->setCellValue('H2', "TDS");
//vendor
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$mm_sheet->setCellValue('J1', "Vendor DATA");
$mm_sheet->setCellValue('J2', "Sl. No");
$mm_sheet->setCellValue('K2', "Invoice No");
$mm_sheet->setCellValue('L2', "Invoice Date");
$mm_sheet->setCellValue('M2', "Document Type");
$mm_sheet->setCellValue('N2', "Debit");
$mm_sheet->setCellValue('O2', "Credit");
$mm_sheet->setCellValue('P2', "Amount Difference");
$query = "SELECT * FROM  manual_match where upload_id = '$upload_id'  and statement_type = 'sap_data'";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $statement_no = $row['statement_no'];
    $query_record = "SELECT * FROM  sap_data where sr_no = '$statement_no'";  
    $row_record = mysqli_query($sql_object->con, $query_record) or die(mysqli_error($sql_object->con));  
    $result_record = mysqli_fetch_assoc($row_record);
    $mm_sheet->setCellValue('A'.($i+2), $i);
    $mm_sheet->setCellValue('B'.($i+2), $result_record['document_number']);
    $mm_sheet->setCellValue('C'.($i+2), date("d/m/Y", strtotime($result_record['posting_date'])));
    $mm_sheet->setCellValue('D'.($i+2), $result_record['document_type']);
    $mm_sheet->setCellValue('E'.($i+2), $result_record['reference_no']);
    $mm_sheet->setCellValue('F'.($i+2), date("d/m/Y", strtotime($result_record['document_date'])));
    $mm_sheet->setCellValue('G'.($i+2), $result_record['amount']);
    $mm_sheet->setCellValue('H'.($i+2), $result_record['tds']);  
}
//for vendor
$query = "SELECT * FROM  manual_match where upload_id = '$upload_id' and statement_type = 'vendor_data'";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object));  
$i=1; 
foreach($result as $row) { 
    $statement_no = $row['statement_no'];
    $query_record = "SELECT * FROM  vendor_data where sr_no = '$statement_no'";
    $row_record = mysqli_query($sql_object->con, $query_record) or die(mysqli_error($sql_object->con)); 
    $result_record = mysqli_fetch_assoc($row_record);    
    $mm_sheet->setCellValue('J'.($i+2), $i);
    $mm_sheet->setCellValue('K'.($i+2), $result_record['invoice_no']);
    $mm_sheet->setCellValue('L'.($i+2), date("d/m/Y", strtotime($result_record['date'])));
    $mm_sheet->setCellValue('M'.($i+2), $result_record['document_type']);
    $mm_sheet->setCellValue('N'.($i+2), $result_record['debit']);
    $mm_sheet->setCellValue('O'.($i+2), $result_record['credit']); 
    $i++;
}
//
$spreadsheet->createSheet();
$spreadsheet->setActiveSheetIndex(2);
$pm_sheet = $spreadsheet->getActiveSheet()->setTitle('Partial Matched');
$pm_sheet->setCellValue('A1', "SAP DATA");
$pm_sheet->setCellValue('A2', "Sl. No");
$pm_sheet->setCellValue('B2', "Document. No");
$pm_sheet->setCellValue('C2', "Posting Date");
$pm_sheet->setCellValue('D2', "Document Type");
$pm_sheet->setCellValue('E2', "Invoice No");
$pm_sheet->setCellValue('F2', "Invoice Date");
$pm_sheet->setCellValue('G2', "Amount");
$pm_sheet->setCellValue('H2', "TDS");
//vendor
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$pm_sheet->setCellValue('J1', "Vendor DATA");
$pm_sheet->setCellValue('J2', "Sl. No");
$pm_sheet->setCellValue('K2', "Invoice No");
$pm_sheet->setCellValue('L2', "Invoice Date");
$pm_sheet->setCellValue('M2', "Document Type");
$pm_sheet->setCellValue('N2', "Debit");
$pm_sheet->setCellValue('O2', "Credit");
$pm_sheet->setCellValue('P2', "Amount Difference");
$query = "SELECT * FROM  sap_data where upload_id = '$upload_id' and match_type='PM' ORDER BY reference_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $pm_sheet->setCellValue('A'.($i+2), $i);
    $pm_sheet->setCellValue('B'.($i+2), $row['document_number']);
    $pm_sheet->setCellValue('C'.($i+2), date("d/m/Y", strtotime($row['posting_date'])));
    $pm_sheet->setCellValue('D'.($i+2), $row['document_type']);
    $pm_sheet->setCellValue('E'.($i+2), $row['reference_no']);
    $pm_sheet->setCellValue('F'.($i+2), date("d/m/Y", strtotime($row['document_date'])));
    $pm_sheet->setCellValue('G'.($i+2), $row['amount']);
    $pm_sheet->setCellValue('H'.($i+2), $row['tds']);  
    //Vendor Details
    $match_id = $row['match_id'];
    $query_sap = "SELECT * FROM  vendor_data where sr_no = '$match_id'";
    $row_sap = mysqli_query($sql_object->con, $query_sap) or die(mysqli_error($sql_object));  
    $post_post = mysqli_fetch_assoc($row_sap);
    $pm_sheet->setCellValue('J'.($i+2), $i);
    $pm_sheet->setCellValue('K'.($i+2), $post_post['invoice_no']);
    $pm_sheet->setCellValue('L'.($i+2), date("d/m/Y", strtotime($post_post['date'])));
    $pm_sheet->setCellValue('M'.($i+2), $post_post['document_type']);
    $pm_sheet->setCellValue('N'.($i+2), $post_post['debit']);
    $pm_sheet->setCellValue('O'.($i+2), $post_post['credit']); 
    $pm_sheet->setCellValue('P'.($i+2), $row['amount'] - ($post_post['debit'] + $post_post['credit'])); 
    $i++;
}
//
$spreadsheet->createSheet();
$spreadsheet->setActiveSheetIndex(3);
$um_sheet = $spreadsheet->getActiveSheet()->setTitle('Un Matched');
$um_sheet->setCellValue('A1', "SAP DATA");
$um_sheet->setCellValue('A2', "Sl. No");
$um_sheet->setCellValue('B2', "Document. No");
$um_sheet->setCellValue('C2', "Posting Date");
$um_sheet->setCellValue('D2', "Document Type");
$um_sheet->setCellValue('E2', "Invoice No");
$um_sheet->setCellValue('F2', "Invoice Date");
$um_sheet->setCellValue('G2', "Amount");
$um_sheet->setCellValue('H2', "TDS");
//vendor
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$um_sheet->setCellValue('J1', "Vendor DATA");
$um_sheet->setCellValue('J2', "Sl. No");
$um_sheet->setCellValue('K2', "Invoice No");
$um_sheet->setCellValue('L2', "Invoice Date");
$um_sheet->setCellValue('M2', "Document Type");
$um_sheet->setCellValue('N2', "Debit");
$um_sheet->setCellValue('O2', "Credit");
$um_sheet->setCellValue('P2', "Amount Difference");
$query = "SELECT * FROM  sap_data where upload_id = '$upload_id' and match_type='UM' ORDER BY reference_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $um_sheet->setCellValue('A'.($i+2), $i);
    $um_sheet->setCellValue('B'.($i+2), $row['document_number']);
    $um_sheet->setCellValue('C'.($i+2), date("d/m/Y", strtotime($row['posting_date'])));
    $um_sheet->setCellValue('D'.($i+2), $row['document_type']);
    $um_sheet->setCellValue('E'.($i+2), $row['reference_no']);
    $um_sheet->setCellValue('F'.($i+2), date("d/m/Y", strtotime($row['document_date'])));
    $um_sheet->setCellValue('G'.($i+2), $row['amount']);
    $um_sheet->setCellValue('H'.($i+2), $row['tds']);  
    $i++;
}
//for vendor
$query = "SELECT * FROM  vendor_data where upload_id = '$upload_id' and remark_dev='' ORDER BY invoice_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $um_sheet->setCellValue('J'.($i+2), $i);
    $um_sheet->setCellValue('K'.($i+2), $row['invoice_no']);
    $um_sheet->setCellValue('L'.($i+2), date("d/m/Y", strtotime($row['date'])));
    $um_sheet->setCellValue('M'.($i+2), $row['document_type']);
    $um_sheet->setCellValue('N'.($i+2), $row['debit']);
    $um_sheet->setCellValue('O'.($i+2), $row['credit']); 
    $i++;
}
//
$spreadsheet->createSheet();
$spreadsheet->setActiveSheetIndex(4);
$sum_sheet = $spreadsheet->getActiveSheet()->setTitle('Summary');
$sum_sheet->setCellValue('A1', "Summary");
$query = "SELECT * FROM  record_detail where upload_id = '$upload_id'";  
$row = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object));  
$result = mysqli_fetch_assoc($row); 
$sum_sheet->setCellValue('A2', "RECONCILATION BETWEEN ".$result['company_name']." (".$result['company_code'].") "." AND ".$result['vendor_name']." (".$result['vendor_code'].")");
$sum_sheet->setCellValue('A3', "For the Period from ".date("d/m/Y", strtotime($result['stmt_start_date']))." To ".date("d/m/Y", strtotime($result['stmt_end_date'])));
$sum_sheet->setCellValue('A4', "Matched Records (".$sql_object -> match_record($upload_id,'FM').") ₹ ".$sql_object -> match_record_amount($upload_id,'FM'));
$sum_sheet->setCellValue('A5', "Manual Records (".$sql_object -> match_record($upload_id,'MM').") ₹ ".$sql_object -> match_record_amount($upload_id,'MM'));
$sum_sheet->setCellValue('A6', "Partial Records (".$sql_object -> match_record($upload_id,'PM').") ₹ ".$sql_object -> match_record_amount($upload_id,'PM'));
$unmantch = abs($sql_object -> match_record($upload_id,'ALL') - ($sql_object -> match_record($upload_id,'PM') + $sql_object -> match_record($upload_id,'FM')));
$sum_sheet->setCellValue('A7', "Un-Matched Records (".$unmantch.") ₹ ".$sql_object -> match_record_amount($upload_id,'UM'));
$sum_sheet->setCellValue('A8', "All Records (".($sql_object -> match_record($upload_id,'ALL')).") ₹ ".($sql_object -> match_record_amount($upload_id,'FM') + $sql_object -> match_record_amount($upload_id,'MM') + $sql_object -> match_record_amount($upload_id,'PM') + $sql_object -> match_record_amount($upload_id,'UM')));

$sum_sheet->setCellValue('F2',$result['company_name']." (".$result['company_code'].") Closing Balance");
$sum_sheet->setCellValue('F3',$result['vendor_name']." (".$result['vendor_code'].") Closing Balance");
$sum_sheet->setCellValue('F4',"Difference:");
$sum_sheet->setCellValue('G2',$result['company_closing_balance']);
$sum_sheet->setCellValue('G3',$result['vendor_closing_balance']);
$sum_sheet->setCellValue('G4',abs($result['company_closing_balance'] - $result['vendor_closing_balance']));


// Reasons Starts
$sum_sheet->setCellValue('A10',"Sl. No");
$sum_sheet->setCellValue('B10',"Gaps Identified");
$sum_sheet->setCellValue('C10',"Vendor");
$sum_sheet->setCellValue('D10',"Welspun");
$sum_sheet->setCellValue('E10',"Total Amount");
$query_reason = "SELECT * FROM master_mismatch_reason where status = 1 ";
$row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
$w_amt = 0;
$v_amt = 0;
$r=10;
 foreach($row_reason as $result_reason) {
    $r++; 
    $w_amt = $w_amt + (int)$sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],2,$result_reason['effect']);
    $v_amt = $v_amt + (int)$sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],1,$result_reason['effect']);
    $sum_sheet->setCellValue('A'.$r,$result_reason['sr_no']);
    $sum_sheet->setCellValue('B'.$r,$result_reason['reason']);
    $sum_sheet->setCellValue('C'.$r,$sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],1,$result_reason['effect']));
    $sum_sheet->setCellValue('D'.$r,$sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],2,$result_reason['effect']));
    $sum_sheet->setCellValue('E'.$r,$sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],1,$result_reason['effect']) + $sql_object -> gaps_identified_amount($upload_id,$result_reason['sr_no'],2,$result_reason['effect']));
}
$sum_sheet->setCellValue('B'.($r+1),"Total:");
$sum_sheet->setCellValue('C'.($r+1),$v_amt);
$sum_sheet->setCellValue('D'.($r+1),$w_amt);
$sum_sheet->setCellValue('E'.($r+1),$v_amt + $w_amt);
//
$spreadsheet->createSheet();
$spreadsheet->setActiveSheetIndex(5);
$dump_sheet = $spreadsheet->getActiveSheet()->setTitle('All RECORDS');
$dump_sheet->setCellValue('A1', "Uploadede Sheet Records");
$dump_sheet->setCellValue('A1', "SAP DATA");
$dump_sheet->setCellValue('A2', "Sl. No");
$dump_sheet->setCellValue('B2', "Document. No");
$dump_sheet->setCellValue('C2', "Posting Date");
$dump_sheet->setCellValue('D2', "Document Type");
$dump_sheet->setCellValue('E2', "Invoice No");
$dump_sheet->setCellValue('F2', "Invoice Date");
$dump_sheet->setCellValue('G2', "Amount");
$dump_sheet->setCellValue('H2', "TDS");
//vendor
//$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$dump_sheet->setCellValue('J1', "Vendor DATA");
$dump_sheet->setCellValue('J2', "Sl. No");
$dump_sheet->setCellValue('K2', "Invoice No");
$dump_sheet->setCellValue('L2', "Invoice Date");
$dump_sheet->setCellValue('M2', "Document Type");
$dump_sheet->setCellValue('N2', "Debit");
$dump_sheet->setCellValue('O2', "Credit");
$dump_sheet->setCellValue('P2', "Amount Difference");
$query = "SELECT * FROM  sap_data where upload_id = '$upload_id' ORDER BY reference_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $dump_sheet->setCellValue('A'.($i+2), $i);
    $dump_sheet->setCellValue('B'.($i+2), $row['document_number']);
    $dump_sheet->setCellValue('C'.($i+2), date("d/m/Y", strtotime($row['posting_date'])));
    $dump_sheet->setCellValue('D'.($i+2), $row['document_type']);
    $dump_sheet->setCellValue('E'.($i+2), $row['reference_no']);
    $dump_sheet->setCellValue('F'.($i+2), date("d/m/Y", strtotime($row['document_date'])));
    $dump_sheet->setCellValue('G'.($i+2), $row['amount']);
    $dump_sheet->setCellValue('H'.($i+2), $row['tds']);  
    $i++;
}
//for vendor
$query = "SELECT * FROM  vendor_data where upload_id = '$upload_id' ORDER BY invoice_no DESC";
$result = mysqli_query($sql_object->con, $query) or die(mysqli_error($sql_object)); 
$i=1; 
foreach($result as $row) { 
    $dump_sheet->setCellValue('J'.($i+2), $i);
    $dump_sheet->setCellValue('K'.($i+2), $row['invoice_no']);
    $dump_sheet->setCellValue('L'.($i+2), date("d/m/Y", strtotime($row['date'])));
    $dump_sheet->setCellValue('M'.($i+2), $row['document_type']);
    $dump_sheet->setCellValue('N'.($i+2), $row['debit']);
    $dump_sheet->setCellValue('O'.($i+2), $row['credit']); 
    $i++;
}
//
$filename = "Report.xlsx";
try {
    $writer = new Xlsx($spreadsheet);
    $writer->save($filename);
    $content = file_get_contents($filename);
} 
catch(Exception $e) { exit($e->getMessage());}

header("Content-Disposition: attachment; filename=".$filename);

unlink($filename);
exit($content);

?>