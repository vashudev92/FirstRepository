<?php include("app/modules/header.php");?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Invoice Record - Module</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Modules</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

     
	  
    <section class="section">
	
	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">SAP Invoices</h5>
              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">Sl. No.</th>
                    <th scope="col">Invoive No</th>
                    <th scope="col">Date</th>
                    <th scope="col">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>WEL/ABX/21-22/453</td>
					<td>2022-05-25</td>
                    <td class="text-end">₹ 3,650.00/-</td>
                  </tr>
                  <tr>
				    <th scope="row">2</th>
                    <td>WEL/ABX/21-22/253</td>
					<td>2022-05-25</td>
                    <td class="text-end">₹ 2,650.00/-</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>WEL/ABX/21-22/463</td>
					<td>2022-05-25</td>
                    <td class="text-end">₹ 44,650.00/-</td>
                  </tr>
                  <tr>
                    <th scope="row">4</th>
                    <td>WEL/ABX/21-22/453</td>
					<td>2022-05-25</td>
                    <td class="text-end">₹ 3,650.00/-</td>
                  </tr>
                  <tr>
                    <th scope="row">5</th>
                    <td>WEL/ABX/21-22/453</td>
					<td>2022-05-25</td>
                    <td class="text-end">₹ 3,450.00/-</td>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>