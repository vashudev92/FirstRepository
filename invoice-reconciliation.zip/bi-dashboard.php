<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
//
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Statement for Reconcilaition - Module</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Modules</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

     
	  
    <section class="section">
	 <!-- Upload Excel Sheet Module Start -->
	  <!-- <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Upload Excel Sheet here...</h5>
			  <form class="row g-12" action="" method="post" name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="col-4">
                  <label for="inputNanme4" class="form-label">Reference Date:</label>
                  <input type="date" class="form-control" id="reference_date" name="reference_date" required>
                </div>
				<div class="col-4">
                  <label for="inputNanme4" class="form-label">Vendor Name:</label>
                  <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
                </div>
				<div class="col-4">
                  <label for="inputNanme4" class="form-label">Vendor Code:</label>
                  <input type="text" class="form-control" id="vendor_code" name="vendor_code" required>
                </div>
				<div class="col-4 p-3">
                  <label for="inputNanme3" class="form-label" >Select Vendor Statement:</label>
                  <input class="form-control" type="file" name="vendor_file" id="vendor_file" accept=".csv" required>
                </div>
				<div class="col-4  p-3">
                  <label for="inputNanme3" class="form-label">Select Company Statement:</label>
                  <input class="form-control" type="file" id="csv_file" name="csv_file" accept=".csv" required>
                </div>
				<div class="col-2  p-3">
                  <label for="inputNanme3" class="form-label">Upload:</label>
                  <button type="submit" class="btn btn-primary" id="submit" name="import">Submit</button>
                </div>
			  </form>
			</div>
		  </div>
		  
		</div>
	  </div> -->
	  <!-- Upload Excel Sheet Module Ends -->
	
	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">
            <iframe title="D-Entry List - D-Entry" width="1140" height="541.25" src="https://app.powerbi.com/reportEmbed?reportId=543ca11a-f496-481f-92d4-552adc1a9026&autoAuth=true&ctid=5b4308bc-4f16-4e8d-aab0-26cc3b6f4bec&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLWluZGlhLXdlc3QtcmVkaXJlY3QuYW5hbHlzaXMud2luZG93cy5uZXQvIn0%3D" frameborder="0" allowFullScreen="true"></iframe>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
