<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
//
$action = "INSERT";
if(ISSET($_GET['token'])){
  $action = "UPDATE";
  $token = $_GET['token'];
  $query = "SELECT * FROM record_detail where upload_id = '$token' ";
  $row = mysqli_query($sql_object->con, $query);
  $result = mysqli_fetch_assoc($row);
}
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" />

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Statement Upload - Module</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Modules</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->     
    <section class="section">
     <!-- Upload Excel Sheet Module Start -->
     <form class="g-12" name="frmCSVImport" id="frmCSVImport" >
            <input type="hidden" name="action" value="<?php echo $action;?>"> 
            <input type="hidden" name="upload_id" value="<?php if(ISSET($_GET['token'])){echo $token;}?>">  
      <div class="row">
        <div class="row">
            <div class="col-3">
                <label for="inputNanme4" class="form-label">Statement Period:</label>
            </div>
            <div class="col-3">
                <label for="inputNanme4" class="form-label">Starting Date:</label>
              <input type="date" class="form-control" id="start_period" name="start_period" required placeholder="Start Date" value="<?php if(ISSET($_GET['token'])){echo $result['stmt_start_date'];}?>">
            </div>
            <div class="col-3">
                <label for="inputNanme4" class="form-label">Ending Date:</label>
              <input type="date" class="form-control" id="end_period" name="end_period" required placeholder="End Date" value="<?php if(ISSET($_GET['token'])){echo $result['stmt_end_date'];}?>">
            </div>
        </div>
        <div class="col-lg-6 mt-2">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Vendor Details</h5>

              <!-- General Form Elements -->
              <div class="row">
                    <div class="col-12 mt-2">
                      <label for="exampleDataList" class="form-label">Select Vendor Name / Code:</label>
       <!-- <input class="form-control"  list="answers" id="answer" name="answer" placeholder="Type to search..." value="<?php if(ISSET($_GET['token'])){ echo $result['vendor_name'],' ['.$result['vendor_code'],']';}?>">
    <datalist id="answers">
<?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY vendor_code  
ORDER BY `master_vendor_cateory`.`vendor_name` ASC";
$row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
foreach($row_reason as $result_reason) { ?>
        <option data-value="<?php echo $result_reason['vendor_code']; ?>"><?php echo $result_reason['vendor_name']; ?> [<?php echo $result_reason['vendor_code']; ?>]</option>
        <?php } ?>
    </datalist> -->

<input
  name="answer"
  id="answer"
  list="applicationCodeList"
  class="disableAutoComplete form-control"
  oninput="myFunction()"
  placeholder="Type to search..." value="<?php if(ISSET($_GET['token'])){ echo $result['vendor_name'],' ['.$result['vendor_code'],']';}?>"
/>
<datalist id="applicationCodeList">
  <?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY vendor_code  
ORDER BY `master_vendor_cateory`.`vendor_name` ASC";
$row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
foreach($row_reason as $result_reason) { ?>
  <option value="<?php echo $result_reason['vendor_name']; ?> [<?php echo $result_reason['vendor_code']; ?>]">
<?php } ?>
</datalist>

    <input type="hidden" name="select_vendor"  id="answer-hidden" value="<?php if(ISSET($_GET['token'])){ echo $result['vendor_name']; ?> [<?php echo $result['vendor_code']; ?>]<?php } ?>" >
                       <!-- <label for="inputNanme4" class="form-label">Select Vendor Name / Code:</label>
<select onchange="get_dashboard_data(this)" id="select_company" name="select_company" class="form-select" aria-label="Floating label select example">
<option value="0">Select Company</option>
<?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY vendor_code  
ORDER BY `master_vendor_cateory`.`vendor_name` ASC";
$row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
foreach($row_reason as $result_reason) { ?>
<option value="<?php echo $result_reason['vendor_code']; ?>" 
><?php echo $result_reason['vendor_name']; ?> (<?php echo $result_reason['vendor_code']; ?>)</option>
<?php } ?> -->
</select> 
                    </div>
            <!-- <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Vendor Name:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['vendor_name'];}?>" class="form-control" id="vendor_name" name="vendor_name" required>
                    </div>
            <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Vendor Code:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['vendor_code'];}?>" class="form-control" id="vendor_code" name="vendor_code" required>
                    </div> -->
                    <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Vendor Opening Balance:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['vendor_opening_balance'];}?>" class="form-control" id="vendor_opening_balance" name="vendor_opening_balance" required onkeypress="return isNumber(event)">
                    </div>
                    <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Vendor Closing Balance</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['vendor_closing_balance'];}?>" class="form-control" id="vendor_closing_balance" name="vendor_closing_balance" required onkeypress="return isNumber(event)">
                    </div>
                    <div class="col-12 mt-2">
                      <label for="inputNanme3" class="form-label" >Select Vendor Statement:</label>
                      <input class="form-control" type="file" name="vendor_file" id="vendor_file" accept=".csv" required>
                    </div>
                </div>

            </div>
          </div>

        </div>

        <div class="col-lg-6 mt-2">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Company Details</h5>
               <div class="col-12 mt-3">
                <label for="inputNanme4" class="form-label">Select Company Name / Code:</label>
                
                      <select onchange="get_dashboard_data(this)" id="select_company" name="select_company" class="form-select" aria-label="Floating label select example">
           <!--  <option value="0">Select Company</option> -->
            <?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY company_code  
ORDER BY `master_vendor_cateory`.`company_name` ASC";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['company_code']; ?>" <?php if(ISSET($_GET['token'])){ if($result['company_code'] == $result_reason['company_code']) { echo "selected"; }}?>
               ><?php echo $result_reason['company_name']; ?> (<?php echo $result_reason['company_code']; ?>)</option>
            <?php } ?>
          </select> 
                    </div>
                    <!-- <div class="col-12 mt-3">
                      <label for="inputNanme4" class="form-label">Company Name:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['company_name'];}?>" class="form-control" id="company_name" name="company_name" required>
                    </div>
                    <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Company Code:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['company_code'];}?>" class="form-control" id="company_code" name="company_code" required>
                    </div> -->
                    <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Company Opening Balance:</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['company_opening_balance'];}?>" class="form-control" id="company_opening_balance" name="company_opening_balance" required onkeypress="return isNumber(event)">
                    </div>
                    <div class="col-12 mt-2">
                      <label for="inputNanme4" class="form-label">Company Closing Balance</label>
                      <input type="text" value="<?php if(ISSET($_GET['token'])){echo $result['company_closing_balance'];}?>" class="form-control" id="company_closing_balance" name="company_closing_balance" required onkeypress="return isNumber(event)">
                    </div>

                    <div class="col-12  mt-2">
                      <label for="inputNanme3" class="form-label">Select Company Statement:</label>
                      <input class="form-control" type="file" id="csv_file" name="csv_file" accept=".csv" required>
                    </div>
              
            </div>
          </div>

        </div>
      </div>

      <div class="row">
        <div class="col-10  p-3"></div>
        <div class="col-2  p-3">
          <button type="submit" class="btn btn-primary float-end" id="mySubmit" name="import" <?php if(ISSET($_GET['token'])){ echo "disabled"; }?>disabled>Submit</button>
        </div>
    </div>
              </form>

      <!-- Upload Excel Sheet Module Ends -->
    
     <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12" id="uploaded_sheet">
          <!-- Data will Display here from Ajax page-->

        </div>
      </div>
      <script type="text/javascript">
      function myFunction() {
  const currentValue = document.getElementById('answer').value;
  document.getElementById("mySubmit").disabled =
    currentValue.length === 0 ||
    document.querySelector('option[value="' + currentValue + '"]') === null;
}
</script>

    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
<script type="text/javascript">
    $("#frmCSVImport").on('submit',(function(e) {
  if(e.isDefaultPrevented())
  { 
  }
    else
    {
      $("#submit").attr("disabled", true);
        $(".loader-layout").toggle();
e.preventDefault();
$.ajax({
url: "app/controls/upload_statement_sql.php",
type: "POST",            
data: new FormData(this), 
contentType: false,       
cache:false,            
processData:false,       
success: function(data)  
{
  //alert(data);
  $('#uploaded_sheet').append(data);
  $(".loader-layout").toggle();

}
});
    }
}));


//
    function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if(charCode == 45) {return true;}
            else if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
    }

//
$('input[list]').on('input', function(e) {
    var $input = $(e.target),
        $options = $('#' + $input.attr('list') + ' option'),
        $hiddenInput = $('#' + $input.attr('id') + '-hidden'),
        label = $input.val();

    $hiddenInput.val(label);

    for(var i = 0; i < $options.length; i++) {
        var $option = $options.eq(i);

        if($option.text() === label) {
            $hiddenInput.val( $option.attr('data-value'));
            break;
        }
    }
});


</script>