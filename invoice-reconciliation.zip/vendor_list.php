<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
//
?>
  <main id="main" class="main">
    <div class="row">
      <div class="col-lg-10">
        <div class="pagetitle">
          <h1>Vendor List - Module</h1>
          <nav>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item">Modules</li>
              <li class="breadcrumb-item active">Vendor List</li>
            </ol>
          </nav>
        </div><!-- End Page Title -->
      </div>
      <div class="col-lg-2">
        <!-- Basic Modal -->
              <!-- <button type="button" class="btn btn-primary" onclick="add_recologic_popup('INSERT','')" >
                Add Vendor
              </button> -->
              <div id="modal_load"></div>

            </div>
          </div>
      </div>
    </div>
    <section class="section">

	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <table class="table rec-table datatable">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#.</th>
                    <th scope="col">Vendor Name.</th>
                    <th scope="col">Vendor Code.</th>
                    <th scope="col">Nature.</th>
                    <th scope="col">Category.</th>
                    <th scope="col">Location.</th>
                    <th scope="col">Email Id.</th>
                    <th scope="col">Phone Number.</th>
                    <!-- <th scope="col">Action</th> -->
                  </tr>
                </thead>
                <tbody>
        <?php 
        $i=1;
        $sqlSelect = "SELECT * FROM master_vendor_cateory";
        $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));
                foreach($post as $row) { 
                  $sr_no = $row['sr_no'];
         ?>
                  <tr class="text-start">
                    <td><?php echo $i; ?></td>
                    <td><?php  echo $row['vendor_name']; ?></td>
                    <td><?php  echo $row['vendor_code']; ?></td>
                    <td><?php  echo $row['nature']; ?></td>
                    <td><?php  echo $row['category']; ?></td>
                    <td><?php  echo $row['location']; ?></td>
                    <td><?php  echo $row['email_id']; ?></td>
                    <td><?php  echo $row['phone_numbers']; ?></td>
                    <!-- <td>
                      <button type="button" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit This Detail"><i class="bi bi-pencil-square" onclick="add_recologic_popup('UPDATE','<?php echo $sr_no; ?>')"></i></button>
                      <button type="button" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete this Record" onclick="delete_recologic('DELETE','<?php echo $sr_no; ?>')"><i class="bi bi-trash-fill"></i></button> 
                    </td> -->
                  </tr>
      <?php $i++; }  ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
  <script type="text/javascript">
    //  this open popup for  Add end Update
function add_recologic_popup(a,b)
{
$(".loader-layout").toggle();
$.post("app/modules/add_recologic_popup.php",{sr_no:b,action:a},
function(data){
  //alert(data);
$("#modal_load").html(data);
$(".loader-layout").toggle();
$("#add_recologic_popup").modal('show');
});
}

// delete reco logic function
function delete_recologic(a,b)
{
  if (confirm('Are You Sure want to Delete This!')) {
      $(".loader-layout").toggle();
      $.post("app/controls/reco_logic_sql.php",{sr_no:b,action:"DELETE"},
      function(data){
        //alert(data);
        alert("Record Deleted Sucessfully!");
        location.reload();
      });
  } else {
      //alert('Why did you press cancel? You should have confirmed');
  }
}
  </script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
