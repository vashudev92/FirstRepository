<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
//
$flag=0;
$join='';
$groupby='';
$whereClauses=array();
// $whereClauses[]='inc_no !="1000"';
// $whereClauses[]= "e.employee_id=sd.employee_id";
$where='';
if(isset($_GET['vendor_name_search']) && $_GET['vendor_name_search'] != 'NULL')
          {
              //$whereClauses=array();
              $vendor_name_search=$_GET['vendor_name_search'];
              $whereClauses[] ="vendor_name LIKE '%".$vendor_name_search."%'";
              $flag=1;
          } 
if (count($whereClauses) > 0) { $where = ' WHERE '.implode(' AND ',$whereClauses); }
    $showRecordPerPage = 10;
    if(isset($_GET['page']) && !empty($_GET['page'])){
    $currentPage = $_GET['page'];
    }
    else{
    $currentPage = 1;
    }
    $startFrom = ($currentPage * $showRecordPerPage) - $showRecordPerPage;
    $totalEmpSQL = "SELECT * FROM sap_data group by upload_id order by time_stamp desc";
    $allEmpResult = mysqli_query($sql_object->con, $totalEmpSQL) or die(mysqli_error($sql_object->con));
    $totalEmployee = mysqli_num_rows($allEmpResult);
    $lastPage = ceil($totalEmployee/$showRecordPerPage);
    $firstPage = 1;
    $nextPage = $currentPage + 1;
    $previousPage = $currentPage - 1; 
    $sqlSelect="SELECT * FROM sap_data". $join . $where  . $groupby ." group by upload_id order by time_stamp desc LIMIT $startFrom, $showRecordPerPage";
    //$sqlSelect = "SELECT * FROM sap_data group by upload_id order by time_stamp desc";
    $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));

// $query="select * from  port_list";
//$result1=$mysql->query($query);
?>
  <main id="main" class="main">
   <form action="uploaded-statement.php" method='get' data-toggle="validator" role="form">
  <div class="row">
    <div class="col-lg-2">
    <div class="pagetitle">
      <h1>Reconcilaition</h1>
      <nav>
        <ol class="breadcrumb">
          <!-- <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item">Modules</li>
          <li class="breadcrumb-item active">Data</li> -->
        </ol>
      </nav>
    </div>
  </div>

  <div class="col-lg-6">
              <button type="button" class="btn btn-primary mb-2  float-end">
                Statement Uploaded: <span class="badge bg-white text-primary"><?php echo $sql_object -> number_record_all('record_detail'); ?></span>
              </button>
              <!-- <button type="button" class="btn btn-secondary mb-2">
                Secondary <span class="badge bg-white text-secondary">4</span>
              </button>
              <button type="button" class="btn btn-success mb-2">
                Success <span class="badge bg-white text-success">4</span>
              </button>
              <button type="button" class="btn btn-danger mb-2">
                Danger <span class="badge bg-white text-danger">4</span>
              </button>
              <button type="button" class="btn btn-warning mb-2">
                Warning <span class="badge bg-white text-warning">4</span>
              </button>
              <button type="button" class="btn btn-info mb-2">
                Info <span class="badge bg-white text-info">4</span>
              </button>
              <button type="button" class="btn btn-light mb-2">
                Light <span class="badge bg-secondary text-light">4</span>
              </button>
              <button type="button" class="btn btn-dark mb-2">
                Dark <span class="badge bg-white text-dark">4</span>
              </button> -->
  </div>
   
    <div class="col-lg-4 row">
      <div class="col-lg-8 nomargin nopadding">
      <input type="text" class="form-control" name="vendor_name_search" id="vendor_name_search" placeholder="Vendor Name..." autocomplete="off" required>
    </div>
    <div class="col-lg-4 nomargin nopadding">
      <button type="submit" class="btn btn-primary float-end">Search</button>
    </div>
    </div>
    </div><!-- End Page Title -->
  </form>

     
	  
    <section class="section">
	 <!-- Upload Excel Sheet Module Start -->
	  <!-- <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Upload Excel Sheet here...</h5>
			  <form class="row g-12" action="" method="post" name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="col-4">
                  <label for="inputNanme4" class="form-label">Reference Date:</label>
                  <input type="date" class="form-control" id="reference_date" name="reference_date" required>
                </div>
				<div class="col-4">
                  <label for="inputNanme4" class="form-label">Vendor Name:</label>
                  <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
                </div>
				<div class="col-4">
                  <label for="inputNanme4" class="form-label">Vendor Code:</label>
                  <input type="text" class="form-control" id="vendor_code" name="vendor_code" required>
                </div>
				<div class="col-4 p-3">
                  <label for="inputNanme3" class="form-label" >Select Vendor Statement:</label>
                  <input class="form-control" type="file" name="vendor_file" id="vendor_file" accept=".csv" required>
                </div>
				<div class="col-4  p-3">
                  <label for="inputNanme3" class="form-label">Select Company Statement:</label>
                  <input class="form-control" type="file" id="csv_file" name="csv_file" accept=".csv" required>
                </div>
				<div class="col-2  p-3">
                  <label for="inputNanme3" class="form-label">Upload:</label>
                  <button type="submit" class="btn btn-primary" id="submit" name="import">Submit</button>
                </div>
			  </form>
			</div>
		  </div>
		  
		</div>
	  </div> -->
	  <!-- Upload Excel Sheet Module Ends -->
	
	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body" style="padding: 8px;">
              <!-- Table with stripped rows -->
              <table class="table rec-table" style="margin: 0px;">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#.</th>
                    <th scope="col">Company Name.</th>
                    <th scope="col">Company Code.</th>
                    <th scope="col">Vendor Name.</th>
                    <th scope="col">Vendor Code.</th>
                    <th scope="col">Vendor Record</th>
                    <th scope="col">Company Record</th>
                    <th scope="col">Exact Match</th>
                    <th scope="col">Partial Match</th>
                    <th scope="col">Status</th>
          <th scope="col" style="width: 187px;">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php 
        $i=1;
        $v_count = 0;
        $s_count = 0;
        $FM_count = 0;
        $PM_count = 0;
        // $sqlSelect = "SELECT * FROM sap_data group by upload_id order by time_stamp desc";
        // $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));
                foreach($post as $row) { 
                  $upload_id = $row['upload_id'];
                  $v_count = $v_count + $sql_object -> number_record($row['upload_id'],'vendor_data');
                  $s_count = $s_count + $sql_object -> number_record($row['upload_id'],'sap_data');
                  $FM_count = $FM_count + $sql_object -> match_record($row['upload_id'],'FM');
                  $PM_count = $PM_count + $sql_object -> match_record($row['upload_id'],'PM');
         ?>
                  <tr class="text-center">
                    <td><?php  echo $i; ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($row['upload_id'] ,'company_name'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($row['upload_id'] ,'company_code'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($row['upload_id'] ,'vendor_name'); ?></td>
                    <td><?php  echo $sql_object -> get_record_detail($row['upload_id'] ,'vendor_code'); ?></td>
                    <td><?php  echo $sql_object -> number_record($row['upload_id'],'vendor_data'); ?></td>
                    <td><?php  echo $sql_object -> number_record($row['upload_id'],'sap_data'); ?></td>
                    <td><?php  echo $sql_object -> match_record($row['upload_id'],'FM'); ?></td>
                    <td><?php  echo $sql_object -> match_record($row['upload_id'],'PM'); ?></td>
                    <td><?php  echo $sql_object -> get_record_status($row['upload_id']); ?></td>
                    <td>
                      <!-- <button type="button" class="btn btn-primary btn-sm" onclick="window.location.href='invoice-reconciliation.php?token=<?php echo $row['upload_id']; ?>'">View</button>
                      <button type="button" class="btn btn-danger btn-sm" onclick="delete_recologic('DELETE','<?php echo $sr_no; ?>')">Delete</button> -->

                      <button type="button" class="btn btn-info" data-bs-toggle="tooltip" data-bs-placement="top" title="View Reco"><i class="bi bi-view-list" onclick="window.location.href='invoice-reconciliation.php?token=<?php echo $row['upload_id']; ?>'"></i></button>

                      <button type="button" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Download Summary Sheet" onclick="window.open('app/modules/download_summary.php?id=<?php echo $upload_id; ?>', '_blank')"><i class="bi bi-download"></i></button>

                      <button type="button" class="btn btn-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Reco"><i class="bi bi-pencil" onclick="window.location.href='upload-excel.php?token=<?php echo $row['upload_id']; ?>'"></i></button>

                      <button type="button" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete this Record" onclick="delete_recologic('DELETE','<?php echo $upload_id; ?>')"><i class="bi bi-trash-fill"></i></button>
                    </td>
                  </tr>
      <?php $i++; }  ?>
                </tbody>
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#.</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col">Total:</th>
                    <th scope="col"><?php echo $v_count;?></th>
                    <th scope="col"><?php echo $s_count;?></th>
                    <th scope="col"><?php echo $FM_count;?></th>
                    <th scope="col"><?php echo $PM_count;?></th>
                    <th scope="col"></th>
          <th scope="col" style="width: 187px;"></th>
                  </tr>
                </thead>
              </table>
              <!-- End Table with stripped rows -->
<div class="col-lg-12 pull-right">

    <nav aria-label="Page navigation" class="navbar navbar-expand-lg navbar-light bg-light float-end">
    <ul class="pagination">
    <?php if($currentPage != $firstPage) { ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?php echo $firstPage ?>" tabindex="-1" aria-label="Previous">
      <span aria-hidden="true">First</span>     
      </a>
    </li>
    <?php } ?>
    <?php if($currentPage >= 2) { ?>
      <li class="page-item"><a class="page-link" href="?page=<?php echo $previousPage ?>"><?php echo $previousPage ?></a></li>
    <?php } ?>
    <li class="page-item active"><a class="page-link" href="?page=<?php echo $currentPage ?>"><?php echo $currentPage ?></a></li>
    <?php if($currentPage != $lastPage) { ?>
      <li class="page-item"><a class="page-link" href="?page=<?php echo $nextPage ?>"><?php echo $nextPage ?></a></li>
      <li class="page-item">
        <a class="page-link" href="?page=<?php echo $lastPage ?>" aria-label="Next">
        <span aria-hidden="true">Last</span>
        </a>
      </li>
    </ul>
  </nav>
 </div> 
<?php } ?>
            </div>
          </div>

        </div>
      </div>
    </section>
<script type="text/javascript">
  function delete_recologic(a,b)
{
  if (confirm('Are You Sure want to Delete This!')) {
      $(".loader-layout").toggle();
      $.post("app/controls/reco_logic_sql.php",{sr_no:b,action:"DELETE_STATEMENTS"},
      function(data){
        //alert(data);
        alert("Statement Deleted Sucessfully!");
        location.reload();
      });
  } else {
      //alert('Why did you press cancel? You should have confirmed');
  }
}

  function download_summary(a,b)
{
      $(".loader-layout").toggle();
      $.post("app/modules/download_summary.php",{sr_no:b,action:a},
      function(data){
        alert(data);
        $(".loader-layout").toggle();
      });
}
</script>
  </main><!-- End #main -->
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
