<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
$token = $_GET['token'];
?>
  <main id="main" class="main" style="padding-top: 10px;">
    <div class="pagetitle row g-12">
	<div class="col-8">
      <h1><i class="ri-chat-download-fill" style="cursor: pointer;" onclick="window.open('app/modules/download_summary.php?id=<?php echo $token; ?>', '_blank')"></i> Vendor Statement Reconciliation - <u><strong id = "display_block">All Records</strong></u></h1>
      <input type="hidden" name="pm_sr_no" id="pm_sr_no">
      <input type="hidden" name="um_sr_no" id="um_sr_no">
      <div id="modal_load"></div>
      <nav>
        <ol class="breadcrumb nomargin">
          <li class="breadcrumb-item active"><?php  echo $sql_object -> get_record_detail($token ,'company_name'); ?>(<?php  echo $sql_object -> get_record_detail($token ,'company_code'); ?>)</li>
          <li class="breadcrumb-item active"><b>Vendor : </b> <?php  echo $sql_object -> get_record_detail($token ,'vendor_name'); ?>(<?php  echo $sql_object -> get_record_detail($token ,'vendor_code'); ?>)</li>
        </ol>
      </nav>
      <h6 id="matching_count">
        <?php 
        $unmantch = abs($sql_object -> match_record($token,'ALL') - ($sql_object -> match_record($token,'PM') + $sql_object -> match_record($token,'FM')));
        ?>
        <span id="btn_all" onclick="get_matching_table('all','<?php echo $token; ?>');" class="badge bg-primary pointer" style="cursor: pointer;">All Record <?php  echo $sql_object -> match_record($token,'ALL'); ?></span>
        <span id="btn_fullmatch" onclick="get_matching_table('FM','<?php echo $token; ?>');" class="badge text-success pointer" style="cursor: pointer;">Matched: <?php  echo $sql_object -> match_record($token,'FM'); ?> </span>
        <span id="btn_partialmatch" onclick="get_matching_table('PM','<?php echo $token; ?>');" class="badge text-warning pointer" style="cursor: pointer;">Partial Matched: <?php  echo $sql_object -> match_record($token,'PM'); ?> </span>
        <span id="btn_unmatch" onclick="get_matching_table('UM','<?php echo $token; ?>');" class="badge text-danger pointer" style="cursor: pointer;">Unmatch: <?php  //echo $unmantch; 
        echo $sql_object -> match_record($token,' ') + $sql_object -> match_record($token,'UM'); ?></span>
        <span id="btn_manualmatch" onclick="get_matching_table('MM','<?php echo $token; ?>');" class="badge text-info pointer" style="cursor: pointer;">Manual Match: <?php echo $sql_object -> match_record($token,'MM'); ?></span> 
       <span id="btn_summary" onclick="get_matching_table('SUM','<?php echo $token; ?>');" class="badge text-dark pointer" style="cursor: pointer;">Summary<?php  //echo $sql_object -> match_record($token,'UM');; ?></span>
        
        <span id="btn_summary" onclick="get_PM_UM_data('<?php echo $token; ?>');" class="badge rounded-pill bg-light text-dark pointer" style="cursor: pointer;">(PM + UM)</span>
      </h6>
	  </div>
	  <div class="col-1">
		 <!--  <button type="button" class="btn btn-success btn-sm" id="button" name="import" onclick="get_matching_table('FM','<?php echo $token; ?>');">Matched Record</button>
		  <button type="button" class="btn btn-danger btn-sm" id="button" name="import" onclick="get_matching_table('UM','<?php echo $token; ?>');">Un-Matched Record</button>
      <button type="button" class="btn btn-warning btn-sm" style="margin-top:5px" id="button" name="import" onclick="get_matching_table('PM','<?php echo $token; ?>');">Partial-Matched Record</button>
		  <button type="button" class="btn btn-primary btn-sm" style="margin-top:5;width: 103px;" id="allrecords" name="import" onclick="get_matching_table('all','<?php echo $token; ?>');">All Record</button> -->
		</div>
    <div class="col-3 row nopadding d-none" id="reco_amt_div">

      <div class="col-6 nopadding ">
        <h6 class= "nopadding nomargin">Welspun Amount:</h6> 
      </div>
      <div class="col-6 nopadding">
        <input type="hidden" id="welspun_reco_amount" name="welspun_reco_amount" readonly value="0"></input type="text">
        <h6 class= "nomargin text-end">₹ <span id="welspun_reco_amount_display">00</span>/-</h6> 
      </div>
      <div class="col-6 nopadding">
        <h6 class= "nopadding nomargin">Vendor Amount:</h6> 
      </div>
      <div class="col-6 nopadding">
        <input type="hidden" id="vendor_reco_amount" name="vendor_reco_amount" readonly value="0"></input type="text">
        <h6 class= "nomargin text-end">₹ <span id="vendor_reco_amount_display">00</span>/-</h6> 
      </div>
      <div class="col-6 nopadding border-top">
        <h6 class= "nopadding nomargin">Diff. Amount:</h6> 
      </div>
      <div class="col-6 nopadding border-top">
        <input type="hidden" id="reco_amount" name="reco_amount" readonly value="0"></input type="text">
        <h6 class= "nomargin text-end">₹ <span id="reco_amount_display">00</span>/-</h6> 
      </div>
      
  </div>
<!-- 	</form> -->
    </div><!-- End Page Title -->

     
	  
    <section class="section" id="matching_table">
	
	 <!-- Data table Module Starts-->
		<?php require_once 'app/modules/matching-tables.php'; ?>
    </section>

  </main><!-- End #main -->
<script>
//get matching constrain table 
function get_matching_table(a,b)
{   //alert (a);
  $("#welspun_reco_amount_display").html('0');
  $("#vendor_reco_amount_display").html('0');
  $("#reco_amount_display").html('0');
  $("#welspun_reco_amount").val('0');
  $("#vendor_reco_amount").val('0');
  $("#reco_amount").val('0');
  if(a == 'UM' || a == 'PM'){$("#reco_amt_div").removeClass("d-none");}else {$("#reco_amt_div").addClass("d-none");}
    $(".loader-layout").toggle();
    $.post("app/modules/matching-tables.php",{resource_id:a,token:b},
        function(data){
			//alert(data);
            $("#matching_table").html(data);
            $.post("app/modules/match_count_number.php",{click:a,token:b}, function(data){$("#matching_count").html(data);});
            $(".loader-layout").toggle();
    });
    //change Button on off
    
}


//check all checkbox of invoice
function welspun_check_all(a){
  $('.'+a).click();
}  
//
function get_PM_UM_data(c){
  $(".loader-layout").toggle();
  var a = $("#pm_sr_no").val();
  var b = $("#um_sr_no").val(); 
    $.post("app/controls/match_PM_UM.php",{welspun_record:a,vendor_record:b,upload_id:c},
          function(data){
            //alert(data);
            $("#modal_load").html(data);
            $("#disablebackdrop").modal('show');
            $(".loader-layout").toggle();
    });
}
</script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
  <link rel="stylesheet" type="text/css" href="assets/vendor/DataTables/datatables.min.css"/>
<script type="text/javascript" src="assets/vendor/DataTables/datatables.min.js"></script>
