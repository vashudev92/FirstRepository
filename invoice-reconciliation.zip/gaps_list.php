<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
$upload_id = $_GET['token'];
$reason_id = $_GET['q'];
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Records in - <?php echo $sql_object -> get_gap_name($reason_id)?></h1>
       <nav>
        <ol class="breadcrumb nomargin">
          <li class="breadcrumb-item active"><?php  echo $sql_object -> get_record_detail($upload_id ,'company_name'); ?>(<?php  echo $sql_object -> get_record_detail($upload_id ,'company_code'); ?>)</li>
          <li class="breadcrumb-item active"><b>Vendor : </b> <?php  echo $sql_object -> get_record_detail($upload_id ,'vendor_name'); ?>(<?php  echo $sql_object -> get_record_detail($upload_id ,'vendor_code'); ?>)</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
	
	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <!-- <h6>Vendor Book</h6> -->
              <table class="table rec-table">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#</th>
                    <th scope="col">Invoice Date</th>
                    <th scope="col">Invoice No.</th>
                    <th scope="col">Description</th>
                    <th scope="col">Welspun A/C amt.</th>
                    <th scope="col">Vendors A/C amt.</th>
                    <th scope="col">Deduction</th>
                    <!-- <th scope="col">Deduction</th> -->
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php 
        $i=1;
        $amount = 0;
        $sqlSelect = "SELECT * FROM reco_summary_amount where upload_id = '$upload_id' and reason = $reason_id";
        $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));
                foreach($post as $row) { $sr_no = $row['sr_no'];
                if($row['attached_stmt'] != 0){$stmt_amt_w = $sql_object -> common_function('sap_data','amount','sr_no',$row['attached_stmt']);} else {$stmt_amt_w = 0;}
                   if($row['statement_type'] == "sap_data") {
                    $stmt_amt = $sql_object -> common_function($row['statement_type'],'amount','sr_no',$row['statement_no']);
                  }
                  else{
                    $stmt_amt = ($sql_object -> common_function($row['statement_type'],'debit','sr_no',$row['statement_no']) +
                    $sql_object -> common_function($row['statement_type'],'credit','sr_no',$row['statement_no']));
                    $vendor_amt_check = $sql_object -> common_function("vendor_data","debit",'sr_no',$row['statement_no']);
                  } 
                  $difference_amount = $row['amount'];
                  if(ISSET($vendor_amt_check) and $vendor_amt_check == 0){ $difference_amount = -$difference_amount; }   
                $amount = $amount + $difference_amount;?>
                  <tr class="text-center">
                    <td><?php echo $i; ?></td>
                    <td><?php  
                    if($row['statement_type'] == "sap_data") 
                      {$field = "reference_no";$field_inv_date = "document_date";} 
                  else {$field = "invoice_no";$field_inv_date = "date";}
                    echo date("d/m/Y", strtotime($sql_object -> common_function($row['statement_type'],$field_inv_date,'sr_no',$row['statement_no']))); ?>
                  </td>
                  <td><?php  
                    if($row['statement_type'] == "sap_data") 
                      {$field = "reference_no";$field_inv_date = "document_date";} 
                  else {$field = "invoice_no";$field_inv_date = "date";}
                    echo $sql_object -> common_function($row['statement_type'],$field,'sr_no',$row['statement_no']);
                    ?>
                  </td>
                  <td><?php  echo $row['comment'] ?></td>

                  <td><?php 
                  echo "₹ ".$stmt_amt_w;
                  ?>   
                  </td>
                  <td><?php 
                    echo "₹ ".$stmt_amt; 
                   ?>            
                  </td>
                    
                    <td><?php  echo $difference_amount; ?></td>
                    <!-- <td></td> -->
                    <td><?php // echo $row['date_time'] ?>
                    <i class="bi bi-trash-fill text-danger" style="cursor: pointer;font-size: 20px;" onclick="delete_record('DELETE_RECORD','<?php echo $sr_no; ?>')" > </i>
                    </td> 
                  </tr>
      <?php $i++; }  ?>
                </tbody>
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"><?php echo $amount; ?></th>
                    <!-- <th scope="col"></th> -->
                    <th scope="col"></th>
                  </tr>
                </thead>
              </table>
              <!-- End Table with stripped rows -->
            </div>
          </div>
        </div>


      </div>
    </section>

  </main><!-- End #main -->
  <script type="text/javascript">
    // delete reco logic function
function delete_record(a,b)
{
  if (confirm('Are You Sure want to Delete This!')) {
      $(".loader-layout").toggle();
      $.post("app/controls/reco_logic_sql.php",{sr_no:b,action:a},
      function(data){
        //alert(data);
        alert("Record Deleted Sucessfully!");
        location.reload();
      });
  } else {
      //alert('Why did you press cancel? You should have confirmed');
  }
}
  </script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>

