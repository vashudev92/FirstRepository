<?php include("app/modules/header.php");
require_once('app/controls/common.php');
$sql_object = new common (); 
//
?>
  <main id="main" class="main">
    <div class="row">
      <div class="col-lg-10">
        <div class="pagetitle">
          <h1>Reco Logic - Module</h1>
          <nav>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item">Modules</li>
              <li class="breadcrumb-item active">Reco Logic</li>
            </ol>
          </nav>
        </div><!-- End Page Title -->
      </div>
      <div class="col-lg-2">
        <!-- Basic Modal -->
              <button type="button" class="btn btn-primary" onclick="add_recologic_popup('INSERT','')" >
                Add Logic
              </button>
              <div id="modal_load"></div>

            </div>
          </div>
      </div>
    </div>
    <section class="section">

	 <!-- Data table Module Starts-->
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Table with stripped rows -->
              <table class="table">
                <thead>
                  <tr  class="text-center">
                    <th scope="col">#.</th>
                    <th scope="col">Logic.</th>
                    <th scope="col">Effect.</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
        <?php 
        $i=1;
        $sqlSelect = "SELECT * FROM master_mismatch_reason ORDER BY sr_no desc";
        $post = mysqli_query($sql_object->con, $sqlSelect) or die(mysqli_error($sql_object->con));
                foreach($post as $row) { 
                  $sr_no = $row['sr_no'];
         ?>
                  <tr class="text-start">
                    <td><?php echo $i; ?></td>
                    <td class=""><?php  echo $row['reason']; ?></td>
                    <td><?php  echo $row['effect']; ?></td>
                    <td>
                      <button type="button" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit This Detail"><i class="bi bi-pencil-square" onclick="add_recologic_popup('UPDATE','<?php echo $sr_no; ?>')"></i></button>
                      <button type="button" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete this Record" onclick="delete_recologic('DELETE','<?php echo $sr_no; ?>')"><i class="bi bi-trash-fill"></i></button> 
                    </td>
                  </tr>
      <?php $i++; }  ?>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
  <script type="text/javascript">
    //  this open popup for  Add end Update
function add_recologic_popup(a,b)
{
$(".loader-layout").toggle();
$.post("app/modules/add_recologic_popup.php",{sr_no:b,action:a},
function(data){
  //alert(data);
$("#modal_load").html(data);
$(".loader-layout").toggle();
$("#add_recologic_popup").modal('show');
});
}

// delete reco logic function
function delete_recologic(a,b)
{
  if (confirm('Are You Sure want to Delete This!')) {
      $(".loader-layout").toggle();
      $.post("app/controls/reco_logic_sql.php",{sr_no:b,action:"DELETE"},
      function(data){
        //alert(data);
        alert("Record Deleted Sucessfully!");
        location.reload();
      });
  } else {
      //alert('Why did you press cancel? You should have confirmed');
  }
}
  </script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
