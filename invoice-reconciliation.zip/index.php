<?php 
include("app/modules/header.php");
$sql_object->check_session();  
?>
  <main id="main" class="main nopadding">

    <div class="pagetitle">
      <h1>Dashboard<?php $sql_object->update_bi_table(); 
      //$sql_object->Insert_bi_table(); ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home </a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div>  

    <section class="section dashboard">
      <div class="row" >
         <iframe title="Vendor_Recotool" width="100%" height="540" src="https://app.powerbi.com/reportEmbed?reportId=719a1341-50d8-4bcb-9b5c-f366e5a8e8bc&autoAuth=true&ctid=5b4308bc-4f16-4e8d-aab0-26cc3b6f4bec&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLWluZGlhLXdlc3QtcmVkaXJlY3QuYW5hbHlzaXMud2luZG93cy5uZXQvIn0%3D" frameborder="0" allowFullScreen="true"></iframe>

      </div>
    </section>


  </main><!-- End #main -->
<script type="text/javascript">
  function get_dashboard_data(a)
    {   //alert (a);
      var a = $("#select_vendor_category").val();
      var b = $("#select_company").val();
      var c = $("#select_finincial_years").val();
        //$(".loader-layout").toggle();
        $.post("app/modules/main_dashboard_data.php",{vendor_category:a,compoany_name:b,finincial_year:c},
            function(data){
          //alert(data);
                $("#total_vendor_count").html(data[0]);
                $("#uplaoded_statement_count").html(data[1]);
                //$(".loader-layout").toggle();
        });
    }
</script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
