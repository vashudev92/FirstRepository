<?php 
include("app/modules/header.php");
$sql_object->check_session(); 
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard<?php //var_dump($_SESSION);?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">
          <div class="col-lg-3 mb-3">
            <select onchange="get_dashboard_data(this)" id="select_company" name="select_company" class="form-select" aria-label="Floating label select example">
            <option value="0">Select Company</option>
            <?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY company_name;";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['company_code']; ?>" 
               ><?php echo $result_reason['company_name']; ?>(<?php echo $result_reason['company_code']; ?>)</option>
            <?php } ?>
          </select> 
          </div>
          <div class="col-lg-3">
            <select onchange="get_dashboard_data(this)" id="select_vendor_category" name="select_vendor_category" class="form-select" aria-label="Floating label select example">
            <option  value="0">Select Vendor Category</option>
            <?php $query_reason = "SELECT * FROM `master_vendor_cateory` GROUP BY category;";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['category']; ?>" 
               >Category: <?php echo $result_reason['category']; ?></option>
            <?php } ?>
          </select>
          </div>
          <div class="col-lg-3">
            <select onchange="get_dashboard_data(this)" id="select_vendor_name" name="select_vendor_name" class="form-select" aria-label="Floating label select example">
            <option  value="0">Select Vendor Category</option>
            <?php $query_reason = "SELECT * FROM `master_vendor_cateory`";
            $row_reason = mysqli_query($sql_object->con, $query_reason) or die(mysqli_error($sql_object)); 
            foreach($row_reason as $result_reason) { ?>
              <option value="<?php echo $result_reason['vendor_code']; ?>" 
               ><?php echo $result_reason['vendor_name']; ?></option>
            <?php } ?>
          </select>
          </div>
          <div class="col-lg-3">
            <select onchange="get_dashboard_data(this)" id="select_finincial_years" name="select_finincial_years" class="form-select" aria-label="Floating label select example">
              <option value="0">Select Finincial Year</option>
              <option value="2021-22">F. Y : 2021-22</option>
              <option value="2022-23">F. Y : 2022-23</option>
          </select>
          </div>
        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">
            <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                        <i class="ri-file-user-fill"></i>
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Total Vendors </span> | 
                      <span class="text-danger regular pt-1 fw-bold" id="total_vendor_count">
                        <?php echo $sql_object->vendor_count(0,0,0);?>
                      </span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->

           <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                        <i class="ri-file-upload-fill"></i>
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Uploaded Stmt. </span> | 
                      <span class="text-danger regular pt-1 fw-bold" id="uplaoded_statement_count">
                        <?php echo $sql_object->uploaded_vendor_count(0,0,0);?>
                      </span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->

           <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-check-circle-fill"></i>
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Reconciled</span> | 
                      <span class="text-danger regular pt-1 fw-bold">100</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->

           <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-x-circle-fill"></i>
                      
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Un Reconciled</span> | 
                      <span class="text-danger regular pt-1 fw-bold">100</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->

<!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-alarm-fill"></i>
                      
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Auto Matched</span> | 
                      <span class="text-danger regular pt-1 fw-bold">1</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->
            <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bx bxs-building-house"></i>
                      
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Manual Matched</span> | 
                      <span class="text-danger regular pt-1 fw-bold">1</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->
            <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bx bxs-buildings"></i>
                      
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Vendor. </span> | 
                      <span class="text-danger regular pt-1 fw-bold">100</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->
            <!-- Card Start-->
            <div class="col-xxl-3 col-md-3">
              <div class="card-dashboard sales-card">
                <div class="d-flex align-items-center">
                  <div class="card-icon-dashboard rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-calendar-plus-fill"></i>
                      
                  </div>
                  <div class="card-body-dashboard ps-3">
                    <h6 class="card-title-dashboard"><span>Company. </span> | 
                      <span class="text-danger regular pt-1 fw-bold">100</span> </h6>
                  </div>
                </div>
              </div>
            </div><!-- Sales Card END-->



<div class="col-xxl-4 col-md-1"></div>
             <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card-dashboard revenue-card">

                <div class="card-body">
                  <h6 class="card-title" style="padding: 10px 0px 2px 0px;text-align: center;">Auto Match</span></h6>


                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-window-sidebar"></i>
                    </div>
                    <div class="ps-3">
                      <h6 >125,500 Records</h6>
                      <span class="text-success small pt-1 fw-bold">
                        45%
                      </span> <span class="text-muted small pt-2 ps-1">Processed</span>

                    </div>
                  </div>
                </div>
              </div>
            </div><!-- End Revenue Card -->


<div class="col-xxl-4 col-md-2">
  <h1 style="text-align: center;margin-top: 50px;">VS</h1>
</div>
            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-4">

              <div class="card-dashboard customers-card">
                <div class="card-body">
                  <h5 class="card-title" style="padding: 10px 0px 2px 0px;text-align: center;">Manual Match</h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-exclamation-circle-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6 >65,500 Records</h6>
                      <span class="text-danger small pt-1 fw-bold">55%</span> </span> <span class="text-muted small pt-2 ps-1">Processed</span>

                    </div>
                  </div>

                </div>
              </div>

            </div><!-- End Customers Card -->

          </div>
        </div><!-- End Left side columns -->

        

      </div>
    </section>
    <!-- <div class="row">
      <div class="col-lg-8"></div>
      <div class="col-lg-4" style="height: 400px;">
<!DOCTYPE html><html><body><iframe src="https://web.powerva.microsoft.com/environments/Default-5b4308bc-4f16-4e8d-aab0-26cc3b6f4bec/bots/new_bot_1783c9d7b8654fbc854b6d3fb3a17d53/webchat" frameborder="0" style="width: 100%; height: 100%;"></iframe></body></html>
</div>
</div> -->
  </main><!-- End #main -->
<script type="text/javascript">
  function get_dashboard_data(a)
    {   //alert (a);
      var a = $("#select_vendor_category").val();
      var b = $("#select_company").val();
      var c = $("#select_finincial_years").val();
        //$(".loader-layout").toggle();
        $.post("app/modules/main_dashboard_data.php",{vendor_category:a,compoany_name:b,finincial_year:c},
            function(data){
          //alert(data);
                $("#total_vendor_count").html(data[0]);
                $("#uplaoded_statement_count").html(data[1]);
                //$(".loader-layout").toggle();
        });
    }
</script>
  <!-- ======= Footer ======= -->
<?php include("app/modules/footer.php");?>
